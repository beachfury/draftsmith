package com.draftsmith.compat;

import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.SignBlockEntity;
import net.minecraft.world.level.block.entity.SignTextSlot;

/**
 * The version seam. Everything that tends to change between Minecraft versions funnels through
 * this package, so porting to another version means re-implementing THIS class — not hunting the
 * codebase. Known differences are noted per method.
 */
public final class Compat {
    private Compat() {}

    // ---- registry lookups --------------------------------------------------
    // 26.x: Identifier + Registry.getValue. 1.21.1: ResourceLocation + Registry.get.
    // Always address blocks/items by REGISTRY ID in shared code — 26.2 moved the per-color
    // constants (LIME_CONCRETE etc.) into ColorCollection, but ids never changed.

    /** Raw block lookup by registry id (returns the registry default on unknown ids). */
    public static Block block(String id) {
        return BuiltInRegistries.BLOCK.getValue(Identifier.parse(id));
    }

    /** Raw item lookup by registry id (returns the registry default on unknown ids). */
    public static Item item(String id) {
        return BuiltInRegistries.ITEM.getValue(Identifier.parse(id));
    }

    // ---- giving items (wand / brush handouts) -------------------------------
    // 26.3: placeItemBackInInventory takes a Prediction arg — SERVER_ONLY for server-initiated
    // gives (there is no client prediction to reconcile). 26.1/26.2 & 1.21.1: just (stack).

    /** Put {@code stack} into the player's inventory (hotbar first, drops at their feet if full). */
    public static void giveItem(net.minecraft.server.level.ServerPlayer p, net.minecraft.world.item.ItemStack stack) {
        p.getInventory().placeItemBackInInventory(stack, net.minecraft.util.Prediction.SERVER_ONLY);
    }

    // ---- chat click events (/draft help) -----------------------------------
    // 26.x: ClickEvent.SuggestCommand record. 1.21.1: new ClickEvent(Action.SUGGEST_COMMAND, s).

    /** A click event that puts {@code command} into the player's chat bar. */
    public static net.minecraft.network.chat.ClickEvent suggestCommand(String command) {
        return new net.minecraft.network.chat.ClickEvent.SuggestCommand(command);
    }

    // ---- sign text (measuring tape numbers) --------------------------------
    // 26.3: getText/setText take a SignTextSlot (FRONT/BACK) instead of the older boolean, and
    // SignText became immutable — lines/color/glow are edited through asMutable()…asImmutable().

    /** Write {@code text} on both faces of the sign at pos — black dye + glow ink, waxed. */
    public static void labelSign(ServerLevel level, BlockPos pos, String text) {
        if (level.getBlockEntity(pos) instanceof SignBlockEntity sbe) {
            Component c = Component.literal(text);
            for (SignTextSlot slot : SignTextSlot.values()) {
                sbe.setText(sbe.getText(slot).asMutable()
                        .setLine(1, c).setColor(DyeColor.BLACK).setTextGlowing(true)
                        .asImmutable(), slot);
            }
            sbe.setWaxed(true); // nobody should be able to edit the numbers
            sbe.setChanged();
            level.sendBlockUpdated(pos, level.getBlockState(pos), level.getBlockState(pos), Block.UPDATE_CLIENTS);
        }
    }
}
