package com.draftsmith.gui;

import com.draftsmith.compat.Compat;
import com.draftsmith.edit.DraftBrush;
import com.draftsmith.edit.DraftEdit;

import eu.pb4.sgui.api.elements.GuiElementBuilder;
import eu.pb4.sgui.api.gui.SimpleGui;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_3917;
import net.minecraft.class_7923;

/**
 * The Brushes screen — configures the paint brush in the player's hand. Every change is
 * written straight onto the item (each brush is its own tool). Palette and mask slots use the
 * vanilla cursor: pick a block up from your inventory, click it into a slot; click with an empty
 * cursor to clear.
 */
public final class DraftBrushGui {

    private DraftBrushGui() {}

    public static void open(class_3222 sp) {
        if (!com.draftsmith.api.DraftSmithApi.access().canUse(sp, com.draftsmith.api.EditAccess.Tool.BRUSH)) {
            DraftEdit.msg(sp, "You don't have permission for the brush tools.");
            return;
        }
        SimpleGui gui = new SimpleGui(class_3917.field_17327, sp, false);
        gui.setTitle(class_2561.method_43470("Build Editor — Brushes"));
        render(gui, sp);
        gui.open();
    }

    private static void render(SimpleGui gui, class_3222 sp) {
        for (int i = 0; i < 54; i++) gui.setSlot(i, DraftEditGui.filler());
        class_1799 brush = heldBrush(sp);

        if (brush == null) {
            gui.setSlot(22, new GuiElementBuilder(class_1802.field_42716)
                    .setName(class_2561.method_43470("Get a paint brush"))
                    .addLoreLine(class_2561.method_43470("Hold the brush, then sneak + right-click to configure it"))
                    .addLoreLine(class_2561.method_43470("Each brush remembers its own settings — keep several!"))
                    .setCallback((i, t, a, g) -> {
                        Compat.giveItem(sp, DraftBrush.createBrush());
                        DraftEdit.msg(sp, "Brush added to your inventory.");
                        render(gui, sp);
                    }).build());
            gui.setSlot(45, DraftEditGui.btn(class_1802.field_8107, "Back to editor", (i, t, a, g) -> DraftEditGui.open(sp)));
            return;
        }
        DraftBrush.Config c = DraftBrush.read(brush);

        // Rows 1-2 — brush types.
        typeBtn(gui, sp, brush, 0, class_1802.field_8110, DraftBrush.Type.SPLATTER, "Splatter", "Scattered random blocks — the path maker");
        typeBtn(gui, sp, brush, 1, class_1802.field_8543, DraftBrush.Type.ROUND, "Round", "Solid stamp — disc on surface, ball in air mode");
        typeBtn(gui, sp, brush, 2, class_1802.field_8270, DraftBrush.Type.OVERLAY, "Overlay", "Repaints the exposed surface only (always surface mode)");
        typeBtn(gui, sp, brush, 3, class_1802.field_8479, DraftBrush.Type.SPRAY, "Spray", "Very sparse dusting — flowers, ore flecks");
        typeBtn(gui, sp, brush, 4, class_1802.field_20395, DraftBrush.Type.WALL, "Wall", "Textures the vertical face you aim at — mix up flat walls");
        typeBtn(gui, sp, brush, 5, class_1802.field_27063, DraftBrush.Type.GRADIENT, "Gradient", "Palette IN ORDER — rings on the ground, bottom-to-top on walls");
        typeBtn(gui, sp, brush, 6, class_1802.field_8696, DraftBrush.Type.BLEND, "Blend", "Re-mixes the blocks already there — erases seams, no palette needed");
        typeBtn(gui, sp, brush, 7, class_1802.field_8831, DraftBrush.Type.RAISE, "Raise", "Mounds the terrain up (fade = smooth hill); palette overrides the fill");
        typeBtn(gui, sp, brush, 8, class_1802.field_8699, DraftBrush.Type.LOWER, "Lower", "Dips the terrain down, re-capping the new surface");
        typeBtn(gui, sp, brush, 9, class_1802.field_8155, DraftBrush.Type.SMOOTH, "Smooth", "Averages bumpy terrain toward its neighbors — repeat to melt edits");
        typeBtn(gui, sp, brush, 10, class_1802.field_8535, DraftBrush.Type.ERASE, "Erase", "Surface mode restores the ground; ball mode clears to air");
        gui.setSlot(16, new GuiElementBuilder(c.surface ? class_1802.field_8270 : class_1802.field_8634)
                .setName(class_2561.method_43470("Mode: " + (c.surface ? "Surface" : "Ball")))
                .addLoreLine(class_2561.method_43470(c.surface
                        ? "Paints the top solid block of each column (paths hug terrain)"
                        : "Paints the full ball where you aim (blobs, leaves, veins)"))
                .addLoreLine(class_2561.method_43470("Click to switch"))
                .setCallback((i, t, a, g) -> { c.surface = !c.surface; save(sp, brush, c); render(gui, sp); }).build());

        // Row 2 — dials + mask.
        gui.setSlot(12, new GuiElementBuilder(class_1802.field_8407)
                .setName(class_2561.method_43470("Size (radius): " + c.size)).setCount(Math.max(1, c.size))
                .addLoreLine(class_2561.method_43470("Left-click +1 · Right-click −1"))
                .setCallback((i, t, a, g) -> { c.size = clamp(c.size + (t.isRight ? -1 : 1), 1, 15); save(sp, brush, c); render(gui, sp); }).build());
        gui.setSlot(13, new GuiElementBuilder(class_1802.field_8725)
                .setName(class_2561.method_43470("Density: " + c.density + "%")).setCount(Math.max(1, Math.min(64, c.density)))
                .addLoreLine(class_2561.method_43470("How much of the stroke area gets painted"))
                .addLoreLine(class_2561.method_43470("Left-click +10 · Right-click −10"))
                .setCallback((i, t, a, g) -> { c.density = clamp(c.density + (t.isRight ? -10 : 10), 10, 100); save(sp, brush, c); render(gui, sp); }).build());
        gui.setSlot(14, new GuiElementBuilder(c.fade ? class_1802.field_8153 : class_1802.field_8620)
                .setName(class_2561.method_43470("Fade edges: " + (c.fade ? "ON" : "OFF")))
                .addLoreLine(class_2561.method_43470("ON = strokes thin out toward the edge (hand-worn look)"))
                .setCallback((i, t, a, g) -> { c.fade = !c.fade; save(sp, brush, c); render(gui, sp); }).build());
        class_1792 maskItem = c.mask.isEmpty() ? class_1802.field_8077 : Compat.item(c.mask);
        gui.setSlot(17, new GuiElementBuilder(maskItem == class_1802.field_8162 ? class_1802.field_8077 : maskItem)
                .setName(class_2561.method_43470(c.mask.isEmpty() ? "Paint over: anything" : "Paint over: only " + pretty(c.mask)))
                .addLoreLine(class_2561.method_43470("Click holding a block to only repaint that block"))
                .addLoreLine(class_2561.method_43470("(protects walls near your path) · empty cursor clears"))
                .setCallback((i, t, a, g) -> {
                    class_1799 carried = sp.field_7512.method_34255();
                    if (!carried.method_7960() && carried.method_7909() instanceof class_1747 bi)
                        c.mask = class_7923.field_41175.method_10221(bi.method_7711()).toString();
                    else c.mask = "";
                    save(sp, brush, c); render(gui, sp);
                }).build());

        // Row 3 — the palette.
        for (int slot = 0; slot < 9; slot++) {
            final int idx = slot;
            String id = idx < c.palette.size() ? c.palette.get(idx) : null;
            class_1792 icon = id != null ? Compat.item(id) : Compat.item("minecraft:light_gray_stained_glass_pane");
            GuiElementBuilder b = new GuiElementBuilder(id != null && icon != class_1802.field_8162 ? icon : (id != null ? class_1802.field_8077 : Compat.item("minecraft:light_gray_stained_glass_pane")))
                    .setName(class_2561.method_43470(id != null ? pretty(id) : "Empty palette slot"))
                    .addLoreLine(class_2561.method_43470("Click holding a block to set · empty cursor clears"))
                    .addLoreLine(class_2561.method_43470("Same block in several slots = more common"));
            gui.setSlot(18 + slot, b.setCallback((i, t, a, g) -> {
                class_1799 carried = sp.field_7512.method_34255();
                if (!carried.method_7960() && carried.method_7909() instanceof class_1747 bi) {
                    String bid = class_7923.field_41175.method_10221(bi.method_7711()).toString();
                    while (c.palette.size() <= idx) c.palette.add(bid);
                    c.palette.set(idx, bid);
                } else if (idx < c.palette.size()) {
                    c.palette.remove(idx);
                }
                save(sp, brush, c); render(gui, sp);
            }).build());
        }

        // Row 5 — the protected list: blocks a stroke must NEVER paint over (masks in reverse —
        // the palette is what the brush paints WITH, this row is what it must leave alone).
        for (int slot = 0; slot < 9; slot++) {
            final int idx = slot;
            String id = idx < c.protect.size() ? c.protect.get(idx) : null;
            class_1792 icon = id != null ? Compat.item(id) : Compat.item("minecraft:red_stained_glass_pane");
            GuiElementBuilder b = new GuiElementBuilder(id != null && icon != class_1802.field_8162 ? icon : (id != null ? class_1802.field_8077 : Compat.item("minecraft:red_stained_glass_pane")))
                    .setName(class_2561.method_43470(id != null ? "Protected: " + pretty(id) : "Empty protected slot"))
                    .addLoreLine(class_2561.method_43470("Click holding a block — that block is NEVER painted over"))
                    .addLoreLine(class_2561.method_43470("All other blocks repaint as normal · empty cursor clears"));
            gui.setSlot(36 + slot, b.setCallback((i, t, a, g) -> {
                class_1799 carried = sp.field_7512.method_34255();
                if (!carried.method_7960() && carried.method_7909() instanceof class_1747 bi) {
                    String bid = class_7923.field_41175.method_10221(bi.method_7711()).toString();
                    while (c.protect.size() <= idx) c.protect.add(bid);
                    c.protect.set(idx, bid);
                } else if (idx < c.protect.size()) {
                    c.protect.remove(idx);
                }
                save(sp, brush, c); render(gui, sp);
            }).build());
        }

        // Row 4 — brush management.
        gui.setSlot(28, new GuiElementBuilder(class_1802.field_42716)
                .setName(class_2561.method_43470("Get another brush"))
                .addLoreLine(class_2561.method_43470("A fresh brush with default settings"))
                .setCallback((i, t, a, g) -> {
                    Compat.giveItem(sp, DraftBrush.createBrush());
                    DraftEdit.msg(sp, "Brush added to your inventory.");
                }).build());
        gui.setSlot(30, DraftEditGui.btn(class_1802.field_8077, "Clear palette",
                (i, t, a, g) -> { c.palette.clear(); save(sp, brush, c); render(gui, sp); }));
        gui.setSlot(32, DraftEditGui.btn(class_1802.field_8255, "Clear protected list",
                (i, t, a, g) -> { c.protect.clear(); save(sp, brush, c); render(gui, sp); }));
        gui.setSlot(34, DraftEditGui.btn(class_1802.field_8557, "Undo last stroke",
                (i, t, a, g) -> DraftEdit.undo(sp, (net.minecraft.class_3218) sp.method_37908())));

        // Row 6 — back + status.
        gui.setSlot(45, DraftEditGui.btn(class_1802.field_8107, "Back to editor", (i, t, a, g) -> DraftEditGui.open(sp)));
        gui.setSlot(49, new GuiElementBuilder(class_1802.field_42716)
                .setName(class_2561.method_43470("Editing: the brush in your hand"))
                .addLoreLine(class_2561.method_43470(c.type.name().charAt(0) + c.type.name().substring(1).toLowerCase()
                        + " · size " + c.size + " · " + (c.palette.isEmpty() ? "no blocks yet" : c.palette.size() + " palette entries")
                        + (c.protect.isEmpty() ? "" : " · " + c.protect.size() + " protected")))
                .build());
    }

    private static void typeBtn(SimpleGui gui, class_3222 sp, class_1799 brush, int slot, class_1792 icon,
                                DraftBrush.Type type, String name, String lore) {
        DraftBrush.Config c = DraftBrush.read(brush);
        boolean sel = c.type == type;
        gui.setSlot(slot, new GuiElementBuilder(icon)
                .setName(class_2561.method_43470((sel ? "▶ " : "") + name + (sel ? " (selected)" : "")))
                .addLoreLine(class_2561.method_43470(lore))
                .setCallback((i, t, a, g) -> { c.type = type; save(sp, brush, c); render(gui, sp); }).build());
    }

    /** The brush being edited: main hand first, then offhand. */
    private static class_1799 heldBrush(class_3222 sp) {
        if (DraftBrush.isBrush(sp.method_6047())) return sp.method_6047();
        if (DraftBrush.isBrush(sp.method_6079())) return sp.method_6079();
        return null;
    }

    private static void save(class_3222 sp, class_1799 brush, DraftBrush.Config c) {
        DraftBrush.write(brush, c);
    }

    private static String pretty(String id) {
        String n = id.contains(":") ? id.substring(id.indexOf(':') + 1) : id;
        return n.replace('_', ' ');
    }

    private static int clamp(int v, int lo, int hi) { return Math.max(lo, Math.min(hi, v)); }
}
