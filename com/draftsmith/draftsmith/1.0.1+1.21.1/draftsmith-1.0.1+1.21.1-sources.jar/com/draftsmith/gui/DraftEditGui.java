package com.draftsmith.gui;

import com.draftsmith.compat.Compat;

import com.draftsmith.edit.DraftEdit;
import com.draftsmith.edit.DraftShapes;

import eu.pb4.sgui.api.elements.GuiElement;
import eu.pb4.sgui.api.elements.GuiElementBuilder;
import eu.pb4.sgui.api.gui.SimpleGui;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.function.Consumer;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3917;

/**
 * The editor home screen — the hub of the build tools (sgui chest GUI; vanilla + Bedrock via
 * Geyser). Quick bar for the everyday actions, plus doors into the Shapes and Measure screens.
 * Material for every build op is the block in the player's hand. Layout:
 *   Row 1  corners · copy/cut/paste · undo/redo
 *   Row 2  fill/walls · stack/move + amount knob
 *   Row 3  Shapes… / Brushes… / Measure… · find center · random texture
 *   Row 4  held-block indicator
 */
public final class DraftEditGui {
    private static final Map<UUID, Integer> AMOUNT = new HashMap<>();

    private DraftEditGui() {}

    private static int amount(UUID id) { return AMOUNT.getOrDefault(id, 5); }

    public static void open(class_3222 sp) {
        SimpleGui gui = new SimpleGui(class_3917.field_18666, sp, false);
        gui.setTitle(class_2561.method_43470("Build Editor"));
        render(gui, sp);
        gui.open();
    }

    private static void render(SimpleGui gui, class_3222 sp) {
        final UUID id = sp.method_5667();
        final class_3218 level = (class_3218) sp.method_37908();
        final int amt = amount(id);
        for (int i = 0; i < 36; i++) gui.setSlot(i, filler());
        // Buttons for tool groups the player lacks permission for stay filler glass.
        var access = com.draftsmith.api.DraftSmithApi.access();
        boolean edit = access.canUse(sp, com.draftsmith.api.EditAccess.Tool.EDIT);
        boolean shapes = access.canUse(sp, com.draftsmith.api.EditAccess.Tool.SHAPES);
        boolean brush = access.canUse(sp, com.draftsmith.api.EditAccess.Tool.BRUSH);
        boolean measure = access.canUse(sp, com.draftsmith.api.EditAccess.Tool.MEASURE);

        // Row 1 — selection, clipboard, safety.
        gui.setSlot(0, cornerBtn(sp, true));
        gui.setSlot(1, cornerBtn(sp, false));
        if (edit) {
            gui.setSlot(3, btn(class_1802.field_8407, "Copy selection", (i, t, a, g) -> DraftEdit.copy(sp, level)));
            gui.setSlot(4, btn(class_1802.field_8868, "Cut selection", (i, t, a, g) -> DraftEdit.cut(sp, level)));
            gui.setSlot(5, btn(class_1802.field_8777, "Paste here", (i, t, a, g) -> DraftEdit.paste(sp, level)));
        }
        gui.setSlot(7, btn(class_1802.field_8557, "Undo last edit", (i, t, a, g) -> DraftEdit.undo(sp, level)));
        gui.setSlot(8, btn(class_1802.field_8251, "Redo", (i, t, a, g) -> DraftEdit.redo(sp, level)));

        // Row 2 — direct build ops + transforms with their amount knob.
        if (edit) {
            gui.setSlot(9, btn(class_1802.field_20391, "Fill selection (held block)", (i, t, a, g) -> withBlock(sp, bs -> DraftEdit.set(sp, level, bs))));
            gui.setSlot(10, btn(class_1802.field_20390, "Walls around selection", (i, t, a, g) -> withBlock(sp, bs -> DraftEdit.walls(sp, level, bs))));
            gui.setSlot(12, btn(class_1802.field_8619, "Stack ×" + amt + " (facing)", (i, t, a, g) -> DraftEdit.stack(sp, level, amount(id))));
            gui.setSlot(13, btn(class_1802.field_8249, "Move " + amt + " (facing)", (i, t, a, g) -> DraftEdit.move(sp, level, amount(id))));
            gui.setSlot(15, btn(class_1802.field_8725, "Amount −1", (i, t, a, g) -> { AMOUNT.put(id, Math.max(1, amount(id) - 1)); render(gui, sp); }));
            gui.setSlot(16, new GuiElementBuilder(class_1802.field_8407).setName(class_2561.method_43470("Amount: " + amt))
                    .addLoreLine(class_2561.method_43470("Used by Stack and Move"))
                    .setCount(Math.max(1, Math.min(64, amt))).build());
            gui.setSlot(17, btn(class_1802.field_8687, "Amount +1", (i, t, a, g) -> { AMOUNT.put(id, Math.min(64, amount(id) + 1)); render(gui, sp); }));
        }

        // Row 3 — the sub-screens + everyday quick buttons.
        if (shapes) gui.setSlot(18, new GuiElementBuilder(class_1802.field_8543)
                .setName(class_2561.method_43470("Shapes…"))
                .addLoreLine(class_2561.method_43470("Circle, square, sphere, cylinder, pyramid, line"))
                .setCallback((i, t, a, g) -> DraftShapesGui.open(sp)).build());
        if (brush) gui.setSlot(20, new GuiElementBuilder(class_1802.field_42716)
                .setName(class_2561.method_43470("Brushes…"))
                .addLoreLine(class_2561.method_43470("Splatter, round, overlay, spray, erase — paint with a brush"))
                .setCallback((i, t, a, g) -> DraftBrushGui.open(sp)).build());
        if (measure) {
            gui.setSlot(22, new GuiElementBuilder(class_1802.field_8788)
                    .setName(class_2561.method_43470("Measure…"))
                    .addLoreLine(class_2561.method_43470("Selection size, find center, measuring tape"))
                    .setCallback((i, t, a, g) -> DraftMeasureGui.open(sp)).build());
            gui.setSlot(24, btn(class_1802.field_8695, "Find center of line",
                    (i, t, a, g) -> DraftShapes.findLineCenter(sp, level)));
        }
        gui.setSlot(26, textureToggle(sp, () -> render(gui, sp)));

        // Row 4 — held-block indicator.
        gui.setSlot(35, heldIndicator(sp));
    }

    // ---- shared bits for all editor screens --------------------------------

    static GuiElement cornerBtn(class_3222 sp, boolean first) {
        return btn(class_1802.field_8406, "Set corner " + (first ? 1 : 2) + " (here)",
                (i, t, a, g) -> { if (first) DraftEdit.setPos1(sp); else DraftEdit.setPos2(sp); });
    }

    static GuiElement heldIndicator(class_3222 sp) {
        class_2680 held = DraftEdit.heldBlock(sp);
        return new GuiElementBuilder(held != null ? sp.method_6047().method_7909() : class_1802.field_8077)
                .setName(class_2561.method_43470(held != null ? "Placing: the block in your hand" : "Hold a block to place")).build();
    }

    static GuiElement filler() {
        return new GuiElementBuilder(byRegistryId("minecraft:gray_stained_glass_pane"))
                .setName(class_2561.method_43470(" ")).build();
    }

    static void withBlock(class_3222 sp, Consumer<class_2680> op) {
        class_2680 bs = DraftEdit.heldBlock(sp);
        if (bs == null) { DraftEdit.msg(sp, "Hold a block to place it."); return; }
        op.accept(bs);
    }

    static GuiElement btn(class_1792 icon, String name, GuiElement.ClickCallback cb) {
        return new GuiElementBuilder(icon).setName(class_2561.method_43470(name)).setCallback(cb).build();
    }

    /**
     * The random-texture toggle, shared by all editor screens: lime dye + "ON" when active,
     * gray dye + "OFF" when not, with the lore saying what a click does.
     */
    static GuiElement textureToggle(class_3222 sp, Runnable rerender) {
        boolean on = DraftEdit.isRandomTexture(sp);
        return new GuiElementBuilder(byRegistryId(on ? "minecraft:lime_dye" : "minecraft:gray_dye"))
                .setName(class_2561.method_43470("Random texture: " + (on ? "ON" : "OFF")))
                .addLoreLine(class_2561.method_43470(on
                        ? "Edits AND hand-placing mix every BLOCK in your hotbar"
                        : "Edits and hand-placing use only the held block"))
                .addLoreLine(class_2561.method_43470("Duplicate hotbar slots make that block more common"))
                .addLoreLine(class_2561.method_43470(on ? "Click to turn OFF" : "Click to turn ON"))
                .setCallback((i, t, a, g) -> { DraftEdit.toggleRandomTexture(sp); rerender.run(); }).build();
    }

    // Registry-ID lookup via the version seam (colored-item CONSTANTS differ across branches).
    private static class_1792 byRegistryId(String id) {
        try {
            class_1792 it = Compat.item(id);
            return (it == null || it == class_1802.field_8162) ? class_1802.field_8892 : it;
        } catch (Exception e) { return class_1802.field_8892; }
    }
}
