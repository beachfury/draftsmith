package com.draftsmith.gui;

import com.draftsmith.edit.DraftEdit;
import com.draftsmith.edit.DraftShapes;

import eu.pb4.sgui.api.elements.GuiElement;
import eu.pb4.sgui.api.elements.GuiElementBuilder;
import eu.pb4.sgui.api.gui.SimpleGui;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3917;

/**
 * The Shapes screen of the editor — pick a shape, dial in its parameters, drop the gold center
 * marker at your feet, and build with the block in your hand. Every build goes through
 * {@link DraftEdit#commit} so it is jailed and undoable like any other edit.
 */
public final class DraftShapesGui {

    /** Per-player shape parameters (session-only). */
    private static final class Params {
        DraftShapes.Shape shape = DraftShapes.Shape.CIRCLE;
        boolean hollow = false;
        int size = 7;       // diameter / side length
        int height = 1;     // extrusion for circle/square, height for cylinder
        int thickness = 1;  // hollow shell / line beam thickness
        int repeat = 1;     // vertical copies
        int spacing = 0;    // air gap between copies
    }

    private static final Map<UUID, Params> PARAMS = new HashMap<>();

    private DraftShapesGui() {}

    private static Params params(UUID id) { return PARAMS.computeIfAbsent(id, k -> new Params()); }

    public static void open(class_3222 sp) {
        if (!com.draftsmith.api.DraftSmithApi.access().canUse(sp, com.draftsmith.api.EditAccess.Tool.SHAPES)) {
            DraftEdit.msg(sp, "You don't have permission for the shapes tools.");
            return;
        }
        SimpleGui gui = new SimpleGui(class_3917.field_17327, sp, false);
        gui.setTitle(class_2561.method_43470("Build Editor — Shapes"));
        render(gui, sp);
        gui.open();
    }

    private static void render(SimpleGui gui, class_3222 sp) {
        final UUID id = sp.method_5667();
        final class_3218 level = (class_3218) sp.method_37908();
        final Params p = params(id);
        for (int i = 0; i < 54; i++) gui.setSlot(i, DraftEditGui.filler());

        // Row 1 — pick a shape.
        shapeBtn(gui, sp, 0, class_1802.field_8543, DraftShapes.Shape.CIRCLE, "Circle", "Flat disc — hollow = ring");
        shapeBtn(gui, sp, 1, class_1802.field_20389, DraftShapes.Shape.SQUARE, "Square", "Flat square — hollow = frame");
        shapeBtn(gui, sp, 2, class_1802.field_8634, DraftShapes.Shape.SPHERE, "Sphere", "Full ball — hollow = shell");
        shapeBtn(gui, sp, 3, class_1802.field_8648, DraftShapes.Shape.CYLINDER, "Cylinder", "Round tower — hollow = tube");
        shapeBtn(gui, sp, 4, class_1802.field_20384, DraftShapes.Shape.PYRAMID, "Pyramid", "Steps in by 1 each layer — hollow = frame layers");
        shapeBtn(gui, sp, 5, class_1802.field_8894, DraftShapes.Shape.LINE, "Line", "Corner 1 → corner 2, any diagonal. Thickness = beam");

        // Style toggle.
        gui.setSlot(7, new GuiElementBuilder(p.hollow ? class_1802.field_8280 : class_1802.field_20395)
                .setName(class_2561.method_43470("Style: " + (p.hollow ? "Hollow" : "Filled")))
                .addLoreLine(class_2561.method_43470("Click to switch. Hollow = ring / frame / shell / tube"))
                .setCallback((i, t, a, g) -> { p.hollow = !p.hollow; render(gui, sp); }).build());

        // Row 2 — parameters. Left-click +1, right-click −1, shift = ±10.
        param(gui, sp, 10, class_1802.field_8407, "Size (width)", p.size,
                v -> p.size = clamp(v, 1, 256), () -> p.size, "Diameter / side length");
        param(gui, sp, 11, class_1802.field_8121, "Height", p.height,
                v -> p.height = clamp(v, 1, 128), () -> p.height, "Layers up (circle/square/cylinder)");
        param(gui, sp, 12, class_1802.field_20390, "Thickness", p.thickness,
                v -> p.thickness = clamp(v, 1, 8), () -> p.thickness, "Hollow wall / line beam thickness");
        param(gui, sp, 14, class_1802.field_8619, "Repeat", p.repeat,
                v -> p.repeat = clamp(v, 1, 8), () -> p.repeat, "Vertical copies of the shape");
        param(gui, sp, 15, class_1802.field_8153, "Spacing", p.spacing,
                v -> p.spacing = clamp(v, 0, 16), () -> p.spacing, "Air gap between repeated copies");

        // Row 4 — actions.
        gui.setSlot(28, new GuiElementBuilder(class_1802.field_8494)
                .setName(class_2561.method_43470("Set center (at your feet)"))
                .addLoreLine(class_2561.method_43470("Odd size = 1 gold block, even size = 2x2"))
                .addLoreLine(class_2561.method_43470("The marker restores the ground when you build"))
                .setCallback((i, t, a, g) -> DraftShapes.setShapeCenter(sp, level, p.size % 2 == 0)).build());
        gui.setSlot(29, btn(class_1802.field_8077, "Clear center marker",
                (i, t, a, g) -> DraftShapes.clearShapeMarker(sp, level)));
        gui.setSlot(31, new GuiElementBuilder(class_1802.field_8733)
                .setName(class_2561.method_43470("Build " + (p.hollow ? "hollow " : "") + p.shape.name().toLowerCase()))
                .addLoreLine(class_2561.method_43470(p.shape == DraftShapes.Shape.LINE
                        ? "Draws corner 1 → corner 2 with the held block"
                        : "Builds on the gold marker (or the block you're aiming at) with the held block"))
                .setCallback((i, t, a, g) -> withBlock(sp, bs ->
                        DraftShapes.buildShape(sp, level, bs, p.shape, p.hollow, p.size, p.height, p.thickness, p.repeat, p.spacing)))
                .build());
        gui.setSlot(33, DraftEditGui.textureToggle(sp, () -> render(gui, sp)));
        gui.setSlot(35, btn(class_1802.field_8557, "Undo last edit", (i, t, a, g) -> DraftEdit.undo(sp, level)));

        // Row 6 — back, corners (for the line tool), held-block indicator.
        gui.setSlot(45, btn(class_1802.field_8107, "Back to editor", (i, t, a, g) -> DraftEditGui.open(sp)));
        gui.setSlot(47, DraftEditGui.cornerBtn(sp, true));
        gui.setSlot(48, DraftEditGui.cornerBtn(sp, false));
        gui.setSlot(51, DraftEditGui.heldIndicator(sp));
    }

    private static void shapeBtn(SimpleGui gui, class_3222 sp, int slot, class_1792 icon,
                                 DraftShapes.Shape shape, String name, String lore) {
        Params p = params(sp.method_5667());
        boolean sel = p.shape == shape;
        gui.setSlot(slot, new GuiElementBuilder(icon)
                .setName(class_2561.method_43470((sel ? "▶ " : "") + name + (sel ? " (selected)" : "")))
                .addLoreLine(class_2561.method_43470(lore))
                .setCallback((i, t, a, g) -> { p.shape = shape; render(gui, sp); }).build());
    }

    private interface IntSetter { void set(int v); }
    private interface IntGetter { int get(); }

    private static void param(SimpleGui gui, class_3222 sp, int slot, class_1792 icon, String name,
                              int value, IntSetter set, IntGetter get, String lore) {
        gui.setSlot(slot, new GuiElementBuilder(icon)
                .setName(class_2561.method_43470(name + ": " + value))
                .setCount(Math.max(1, Math.min(64, value)))
                .addLoreLine(class_2561.method_43470(lore))
                .addLoreLine(class_2561.method_43470("Left-click +1 · Right-click −1 · Shift = ±10"))
                .setCallback((i, t, a, g) -> {
                    int step = t.shift ? 10 : 1;
                    set.set(get.get() + (t.isRight ? -step : step));
                    render(gui, sp);
                }).build());
    }

    private static int clamp(int v, int lo, int hi) { return Math.max(lo, Math.min(hi, v)); }

    private static void withBlock(class_3222 sp, java.util.function.Consumer<class_2680> op) {
        class_2680 bs = DraftEdit.heldBlock(sp);
        if (bs == null) { DraftEdit.msg(sp, "Hold a block to place it."); return; }
        op.accept(bs);
    }

    private static GuiElement btn(class_1792 icon, String name, GuiElement.ClickCallback cb) {
        return new GuiElementBuilder(icon).setName(class_2561.method_43470(name)).setCallback(cb).build();
    }
}
