package com.draftsmith.gui;

import com.draftsmith.edit.DraftEdit;
import com.draftsmith.edit.DraftMeasure;
import com.draftsmith.edit.DraftShapes;

import eu.pb4.sgui.api.elements.GuiElementBuilder;
import eu.pb4.sgui.api.gui.SimpleGui;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3917;

/**
 * The Measure screen of the editor — everything measuring in one place: a live readout of the
 * corner 1 → corner 2 selection size, the gold find-center marker, and the yellow/black
 * measuring tape with numbered signs. Nothing here costs blocks permanently — the marker and
 * tape are self-cleaning.
 */
public final class DraftMeasureGui {

    private DraftMeasureGui() {}

    public static void open(class_3222 sp) {
        if (!com.draftsmith.api.DraftSmithApi.access().canUse(sp, com.draftsmith.api.EditAccess.Tool.MEASURE)) {
            DraftEdit.msg(sp, "You don't have permission for the measure tools.");
            return;
        }
        SimpleGui gui = new SimpleGui(class_3917.field_17326, sp, false);
        gui.setTitle(class_2561.method_43470("Build Editor — Measure"));
        render(gui, sp);
        gui.open();
    }

    private static void render(SimpleGui gui, class_3222 sp) {
        final class_3218 level = (class_3218) sp.method_37908();
        for (int i = 0; i < 27; i++) gui.setSlot(i, DraftEditGui.filler());

        // Row 1 — corners + live selection readout.
        gui.setSlot(0, DraftEditGui.btn(class_1802.field_8406, "Set corner 1 (here)",
                (i, t, a, g) -> { DraftEdit.setPos1(sp); render(gui, sp); }));
        gui.setSlot(1, DraftEditGui.btn(class_1802.field_8406, "Set corner 2 (here)",
                (i, t, a, g) -> { DraftEdit.setPos2(sp); render(gui, sp); }));
        String info = DraftMeasure.selectionInfo(sp);
        gui.setSlot(4, new GuiElementBuilder(info != null ? class_1802.field_8895 : class_1802.field_8407)
                .setName(class_2561.method_43470(info != null ? "Selection: " + info : "No selection yet"))
                .addLoreLine(class_2561.method_43470(info != null
                        ? "Width x Height x Length between your corners"
                        : "Set corner 1 and corner 2 to see its size"))
                .build());

        // Row 2 — the measuring tools.
        gui.setSlot(9, new GuiElementBuilder(class_1802.field_8695)
                .setName(class_2561.method_43470("Find center of line"))
                .addLoreLine(class_2561.method_43470("Marks the middle of corner 1 → corner 2 with gold"))
                .addLoreLine(class_2561.method_43470("Odd length = 1 block, even = the middle 2"))
                .addLoreLine(class_2561.method_43470("Doubles as the shape center — build right on it"))
                .setCallback((i, t, a, g) -> DraftShapes.findLineCenter(sp, level)).build());
        gui.setSlot(12, new GuiElementBuilder(class_1802.field_8788)
                .setName(class_2561.method_43470("Measuring tape"))
                .addLoreLine(class_2561.method_43470("Yellow/black stripes corner 1 → corner 2 (straight runs)"))
                .addLoreLine(class_2561.method_43470("Counts from 1; numbered signs every 2, 5, or 10"))
                .setCallback((i, t, a, g) -> DraftMeasure.tape(sp, level)).build());
        gui.setSlot(14, new GuiElementBuilder(class_1802.field_8077)
                .setName(class_2561.method_43470("Clear measuring tape"))
                .addLoreLine(class_2561.method_43470("Puts back exactly what the tape covered"))
                .setCallback((i, t, a, g) -> DraftMeasure.clearTape(sp, level)).build());

        // Row 3 — back.
        gui.setSlot(18, DraftEditGui.btn(class_1802.field_8107, "Back to editor", (i, t, a, g) -> DraftEditGui.open(sp)));
    }
}
