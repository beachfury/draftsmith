package com.draftsmith.api;

import net.minecraft.class_1937;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3222;

/**
 * The one seam between the editor and the world it runs in. Every block the editor writes is
 * checked through this interface, so the host decides where the editor works, who may use it,
 * and how far an edit may reach. DraftSmith ships a conservative ops-only default; a host mod
 * (e.g. a plot-world mod) replaces it via {@link DraftSmithApi#setAccess} to jail edits to its
 * own ownership rules.
 */
public interface EditAccess {

    /** Where the editor runs at all — events, brushes and commands are inert elsewhere. */
    boolean isActiveDimension(class_1937 level);

    /** May this player use the editor at all (commands, wand, brushes, GUIs)? */
    default boolean canUse(class_3222 p) { return true; }

    /** The editor's tool groups — the granularity servers grant permissions at. */
    enum Tool { WAND, EDIT, SHAPES, BRUSH, MEASURE }

    /**
     * May this player use this tool group? Defaults to {@link #canUse} (all tools together) —
     * the built-in provider splits them into draftsmith.wand/edit/shapes/brush/measure nodes
     * when a permissions mod is installed.
     */
    default boolean canUse(class_3222 p, Tool tool) { return canUse(p); }

    /**
     * Unclamped editing. Computed once per stroke and passed back into
     * {@link #canEdit(class_3222, boolean, int, int, int)} so implementations can skip
     * per-block permission lookups.
     */
    boolean isAdmin(class_3222 p);

    /** Can this player write at x/y/z? The jail — every single block write is asked. */
    boolean canEdit(class_3222 p, boolean admin, int x, int y, int z);

    /** Lowest editable Y (used to clamp selection loops before the per-block check). */
    default int minY(class_3218 level) { return level.method_31607(); } // 26.x: getMinY()

    /** Highest editable Y. 1.21.1's getMaxBuildHeight() is EXCLUSIVE — the -1 matters. */
    default int maxY(class_3218 level) { return level.method_31600() - 1; } // 26.x: getMaxY() (inclusive)

    /**
     * What "erase to ground" means at this column, or null when there is no ground concept —
     * the Erase brush then just clears a band around the aim point. When non-null, Erase clears
     * everything above {@code y}, repaints {@code y} with {@code surface} (when non-null), and
     * refills holes dug below it.
     */
    default Ground ground(class_3218 level, int x, int z) { return null; }

    /** Ground level for the Erase brush: floor Y plus the floor block (null = don't repaint). */
    record Ground(int y, class_2680 surface) {}

    /**
     * @deprecated No longer used — the editor's chat messages always reference its own /draft
     * commands, which exist on every server that runs DraftSmith (bundled or standalone). Hosts
     * can delete their override; this default remains only so existing providers still compile.
     */
    @Deprecated(forRemoval = true)
    default String commandRoot() { return "draft"; }

    /** Prefix on every chat line the editor sends. */
    default String messagePrefix() { return "[Draft] "; }

    /** Shown when an editor command is used outside an active dimension. */
    default String notHereMessage() { return "The editor isn't enabled in this world."; }

    /** What the editable area is called in chat ("outside your plot" vs "outside your editable area"). */
    default String editableAreaName() { return "your editable area"; }
}
