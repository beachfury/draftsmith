package com.draftsmith.edit;

import com.draftsmith.compat.Compat;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3222;

/**
 * Measuring tools: the caution-stripe measuring tape (temporary, self-restoring) and the
 * selection size readout. Tapes snapshot every block they cover, so laying a new one or
 * clearing restores exactly what was there.
 */
public final class DraftMeasure {
    // Up to 4 tapes per player (e.g. boxing in a footprint); laying a 5th retires the oldest.
    private static final int MAX_TAPES = 4;
    private static final Map<UUID, ArrayDeque<List<DraftEdit.Snapshot>>> TAPE = new HashMap<>();

    private DraftMeasure() {}

    /** Current selection as "W x H x L — n blocks", or null if either corner is unset. */
    public static String selectionInfo(class_3222 sp) {
        class_2338 p1 = DraftEdit.POS1.get(sp.method_5667()), p2 = DraftEdit.POS2.get(sp.method_5667());
        if (p1 == null || p2 == null) return null;
        int w = Math.abs(p2.method_10263() - p1.method_10263()) + 1;
        int h = Math.abs(p2.method_10264() - p1.method_10264()) + 1;
        int l = Math.abs(p2.method_10260() - p1.method_10260()) + 1;
        return w + " x " + h + " x " + l + " — " + String.format("%,d", (long) w * h * l) + " blocks";
    }

    /**
     * Lay a caution-stripe measuring tape from corner 1 to corner 2 — straight runs only (one
     * axis). Yellow/black alternates every block, counting from 1 at corner 1; numbered signs go
     * every 2, 5, or 10 blocks depending on length (start and end are always numbered). Horizontal
     * runs get signs standing on top; vertical runs get wall signs facing you. Temporary: laying a
     * new tape or clearing restores exactly what was there.
     */
    public static int tape(class_3222 sp, class_3218 level) {
        UUID id = sp.method_5667();
        class_2338 p1 = DraftEdit.POS1.get(id), p2 = DraftEdit.POS2.get(id);
        if (p1 == null || p2 == null) { DraftEdit.msg(sp, "Set corner 1 and corner 2 first — the tape runs between them."); return 0; }
        int dx = p2.method_10263() - p1.method_10263(), dy = p2.method_10264() - p1.method_10264(), dz = p2.method_10260() - p1.method_10260();
        int nonZero = (dx != 0 ? 1 : 0) + (dy != 0 ? 1 : 0) + (dz != 0 ? 1 : 0);
        if (nonZero > 1) { DraftEdit.msg(sp, "The tape runs straight only — line corners 1 and 2 up on a single axis."); return 0; }
        int n = Math.max(Math.abs(dx), Math.max(Math.abs(dy), Math.abs(dz))) + 1;
        if (n > DraftLimits.MAX_BLOCKS) {
            DraftEdit.msg(sp, "That tape is too long to create safely.");
            return 0;
        }
        ArrayDeque<List<DraftEdit.Snapshot>> tapes = TAPE.computeIfAbsent(id, k -> new ArrayDeque<>());
        while (tapes.size() >= MAX_TAPES) restoreTape(sp, level, tapes.pollFirst()); // retire the oldest

        int interval = n <= 20 ? 2 : n <= 50 ? 5 : 10;
        int sx = Integer.signum(dx), sy = Integer.signum(dy), sz = Integer.signum(dz);
        boolean vertical = dy != 0;
        boolean admin = DraftEdit.access().isAdmin(sp);
        class_2248 yellow = DraftEdit.blockById("minecraft:yellow_concrete"), black = DraftEdit.blockById("minecraft:black_concrete");
        class_2248 standing = DraftEdit.blockById("minecraft:oak_sign"), wall = DraftEdit.blockById("minecraft:oak_wall_sign");
        // Signs face back at wherever the player is standing when the tape is laid.
        class_2350 toPlayer = sp.method_5735().method_10153();

        List<DraftEdit.Snapshot> snaps = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            class_2338 pos = p1.method_10069(sx * i, sy * i, sz * i);
            if (!DraftEdit.canEdit(sp, admin, pos.method_10263(), pos.method_10264(), pos.method_10260())) continue;
            if (level.method_8321(pos) != null || DraftEdit.blockEntityState(level.method_8320(pos))) continue;
            snaps.add(new DraftEdit.Snapshot(pos, level.method_8320(pos)));
            level.method_8652(pos, (i % 2 == 0 ? yellow : black).method_9564(), class_2248.field_31028);

            int number = i + 1;
            if (number != 1 && number != n && number % interval != 0) continue;
            if (!vertical) {
                class_2338 signPos = pos.method_10084();
                if (!DraftEdit.canEdit(sp, admin, signPos.method_10263(), signPos.method_10264(), signPos.method_10260())) continue;
                if (level.method_8321(signPos) != null || DraftEdit.blockEntityState(level.method_8320(signPos))) continue;
                snaps.add(new DraftEdit.Snapshot(signPos, level.method_8320(signPos)));
                int rot = (int) (toPlayer.method_10144() / 22.5f) & 15;
                level.method_8652(signPos, standing.method_9564()
                        .method_11657(net.minecraft.class_2508.field_11559, rot), class_2248.field_31028);
                labelSign(level, signPos, number);
            } else {
                class_2338 signPos = pos.method_10093(toPlayer);
                if (!DraftEdit.canEdit(sp, admin, signPos.method_10263(), signPos.method_10264(), signPos.method_10260())) continue;
                if (level.method_8321(signPos) != null || DraftEdit.blockEntityState(level.method_8320(signPos))) continue;
                snaps.add(new DraftEdit.Snapshot(signPos, level.method_8320(signPos)));
                level.method_8652(signPos, wall.method_9564()
                        .method_11657(net.minecraft.class_2551.field_11726, toPlayer), class_2248.field_31028);
                labelSign(level, signPos, number);
            }
        }
        tapes.addLast(snaps);
        DraftEdit.msg(sp, "Tape laid — " + n + " blocks, numbered every " + interval + " (" + tapes.size() + "/" + MAX_TAPES + " tapes). /draft tape clear removes them all.");
        return 1;
    }

    private static void labelSign(class_3218 level, class_2338 pos, int number) {
        Compat.labelSign(level, pos, String.valueOf(number)); // version seam — sign API lives in compat
    }

    /** Remove the player's tape, restoring what each stripe/sign covered (skips blocks changed since). */
    public static void clearTape(class_3222 sp, class_3218 level) {
        ArrayDeque<List<DraftEdit.Snapshot>> tapes = TAPE.remove(sp.method_5667());
        if (tapes == null) return;
        while (!tapes.isEmpty()) restoreTape(sp, level, tapes.pollFirst());
    }

    private static void restoreTape(class_3222 sp, class_3218 level, List<DraftEdit.Snapshot> snaps) {
        if (snaps == null) return;
        class_2248 yellow = DraftEdit.blockById("minecraft:yellow_concrete"), black = DraftEdit.blockById("minecraft:black_concrete");
        boolean admin = DraftEdit.access().isAdmin(sp);
        for (DraftEdit.Snapshot s : snaps) {
            class_2680 cur = level.method_8320(s.pos());
            if (DraftEdit.canEdit(sp, admin, s.pos().method_10263(), s.pos().method_10264(), s.pos().method_10260())
                    && !DraftEdit.blockEntityState(s.old())
                    && (cur.method_27852(yellow) || cur.method_27852(black) || cur.method_26204() instanceof net.minecraft.class_2478))
                level.method_8652(s.pos(), s.old(), class_2248.field_31028);
        }
    }
}
