package com.draftsmith.edit;

import com.draftsmith.api.DraftSmithApi;
import com.draftsmith.api.EditAccess;
import com.draftsmith.compat.Compat;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.minecraft.class_1269;
import net.minecraft.class_1271;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_239;
import net.minecraft.class_2398;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3965;
import net.minecraft.class_9279;
import net.minecraft.class_9334;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

/**
 * Paint brushes — a brush item whose whole configuration lives ON the item (custom data
 * component), so every brush is its own tool: keep a gravel-path splatter in slot 1 and a leaf
 * blob in slot 2 and swap like a painter. Right-click paints where you aim (30 blocks); sneak +
 * right-click opens the config GUI. Strokes are jailed through the editor pipeline, land as
 * one undo entry each, and a particle ring previews the radius while you aim.
 */
public final class DraftBrush {
    public static final String BRUSH_NAME = "Paint Brush";
    // The vanilla archaeology brush — thematically right, and NOT a stick: Litematica and friends
    // claim the stick as their client-side tool and eat the right-click before it reaches us.
    static final net.minecraft.class_1792 BRUSH_ITEM = class_1802.field_42716;
    private static final String TAG = "draftsmith_brush";
    private static final String LEGACY_TAG = "fabricplots_brush"; // brushes made by FabricPlots ≤0.4.0
    private static final int REACH = 30;
    private static final java.util.Random RNG = new java.util.Random();

    public enum Type { SPLATTER, ROUND, OVERLAY, SPRAY, ERASE, WALL, RAISE, LOWER, SMOOTH, GRADIENT, BLEND }

    /** Brush settings, (de)serialized from the item's custom-data tag. */
    public static final class Config {
        public Type type = Type.SPLATTER;
        public int size = 4;            // radius, 1..15
        public int density = 60;        // % of area a splatter/spray stroke covers, 10..100
        public boolean fade = true;     // edges thin out
        public boolean surface = true;  // paint the top solid block of each column
        public String mask = "";        // only repaint this block id ("" = anything)
        public final List<String> palette = new ArrayList<>();
        public final List<String> protect = new ArrayList<>(); // never paint over these block ids
    }

    private DraftBrush() {}

    private static EditAccess access() { return DraftSmithApi.access(); }

    // ---- the brush item ----------------------------------------------------

    public static class_1799 createBrush() {
        class_1799 s = new class_1799(BRUSH_ITEM);
        s.method_57379(class_9334.field_49631, class_2561.method_43470(BRUSH_NAME));
        write(s, new Config());
        return s;
    }

    public static boolean isBrush(class_1799 s) {
        if (s.method_7960() || s.method_7909() != BRUSH_ITEM) return false;
        class_9279 d = s.method_57824(class_9334.field_49628);
        if (d == null) return false;
        class_2487 t = d.method_57461();
        return t.method_10545(TAG) || t.method_10545(LEGACY_TAG);
    }

    public static Config read(class_1799 s) {
        Config c = new Config();
        class_9279 d = s.method_57824(class_9334.field_49628);
        if (d == null) return c;
        class_2487 root = d.method_57461();
        // 1.21.1 CompoundTag has no *Or getters (26.x: getStringOr/getIntOr/getBooleanOr) — the
        // contains() guards matter for the booleans, whose absent-default is TRUE, not false.
        class_2487 t = root.method_10545(TAG) ? root.method_10562(TAG) : root.method_10562(LEGACY_TAG);
        try { c.type = Type.valueOf(t.method_10545("type") ? t.method_10558("type") : "SPLATTER"); } catch (Exception ignored) {}
        c.size = Math.max(1, Math.min(15, t.method_10545("size") ? t.method_10550("size") : 4));
        c.density = Math.max(10, Math.min(100, t.method_10545("density") ? t.method_10550("density") : 60));
        c.fade = !t.method_10545("fade") || t.method_10577("fade");
        c.surface = !t.method_10545("surface") || t.method_10577("surface");
        c.mask = t.method_10558("mask");
        String pal = t.method_10558("palette");
        if (!pal.isEmpty()) for (String id : pal.split(",")) if (!id.isBlank()) c.palette.add(id);
        String prot = t.method_10558("protect"); // 1.21.1: no *Or getter; absent = ""
        if (!prot.isEmpty()) for (String id : prot.split(",")) if (!id.isBlank()) c.protect.add(id);
        return c;
    }

    public static void write(class_1799 s, Config c) {
        class_9279 d = s.method_57824(class_9334.field_49628);
        class_2487 root = d != null ? d.method_57461() : new class_2487();
        class_2487 t = new class_2487();
        t.method_10582("type", c.type.name());
        t.method_10569("size", c.size);
        t.method_10569("density", c.density);
        t.method_10556("fade", c.fade);
        t.method_10556("surface", c.surface);
        t.method_10582("mask", c.mask);
        t.method_10582("palette", String.join(",", c.palette));
        t.method_10582("protect", String.join(",", c.protect));
        root.method_10551(LEGACY_TAG); // migrate legacy brushes to the new tag on first write
        root.method_10566(TAG, t);
        s.method_57379(class_9334.field_49628, class_9279.method_57456(root));
    }

    // ---- events ------------------------------------------------------------

    /** openGui is injected by the initializer wiring so edit/ never depends on gui/. */
    public static void register(Consumer<class_3222> openGui) {
        // 1.21.1 fabric-api: UseItemCallback returns InteractionResultHolder<ItemStack> (26.x: plain InteractionResult).
        UseItemCallback.EVENT.register((player, world, hand) -> {
            class_1799 held = player.method_5998(hand);
            if (!access().isActiveDimension(world)) return class_1271.method_22430(held);
            if (!isBrush(held)) return class_1271.method_22430(held);
            if (world.method_8608() || !(player instanceof class_3222 sp)) return class_1271.method_22427(held);
            if (!access().canUse(sp, EditAccess.Tool.BRUSH)) return class_1271.method_22430(held);
            if (player.method_5715()) PENDING_GUI.add(sp.method_5667()); else paint(sp, held);
            return class_1271.method_22427(held);
        });
        // Clicking directly on a block fires UseBlock first — same behavior, and swallow the click
        // so the brush never opens chests / presses buttons mid-stroke.
        UseBlockCallback.EVENT.register((player, world, hand, hit) -> {
            if (!access().isActiveDimension(world)) return class_1269.field_5811;
            class_1799 held = player.method_5998(hand);
            if (!isBrush(held)) return class_1269.field_5811;
            if (world.method_8608() || !(player instanceof class_3222 sp)) return class_1269.field_5812;
            if (!access().canUse(sp, EditAccess.Tool.BRUSH)) return class_1269.field_5811;
            if (player.method_5715()) PENDING_GUI.add(sp.method_5667()); else paint(sp, held);
            return class_1269.field_5812;
        });
        // GUI opens are queued and drained here — end-of-tick, safely after the click packet that
        // requested them (opening inside the interaction gets closed by the client immediately).
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            boolean preview = server.method_3780() % 4 == 0;
            if (PENDING_GUI.isEmpty() && !preview) return;
            for (class_3218 level : server.method_3738()) {
                if (!access().isActiveDimension(level)) continue;
                for (class_3222 sp : level.method_18456()) {
                    if (PENDING_GUI.remove(sp.method_5667())) openGui.accept(sp);
                    if (!preview) continue;
                    class_1799 held = sp.method_6047();
                    if (isBrush(held)) { if (access().canUse(sp, EditAccess.Tool.BRUSH)) previewRing(sp, level, read(held).size); }
                    else if (DraftEdit.isWand(held)) { if (access().canUse(sp, EditAccess.Tool.WAND)) outlineSelection(sp, level); }
                }
            }
            PENDING_GUI.clear(); // anyone who left the active dimensions mid-click
        });
    }

    private static final java.util.Set<java.util.UUID> PENDING_GUI = new java.util.HashSet<>();

    // ---- painting ----------------------------------------------------------

    static void paint(class_3222 sp, class_1799 brush) {
        class_3218 level = (class_3218) sp.method_37908();
        class_239 hit = sp.method_5745(REACH, 0f, false);
        if (hit.method_17783() != class_239.class_240.field_1332) { DraftEdit.msg(sp, "Aim at a block within " + REACH + " blocks."); return; }
        class_2338 center = ((class_3965) hit).method_17777();
        Config c = read(brush);

        List<class_2680> palette = new ArrayList<>();
        for (String id : c.palette) { class_2248 b = Compat.block(id); if (b != class_2246.field_10124) palette.add(b.method_9564()); }
        boolean needsPalette = switch (c.type) {
            case SPLATTER, ROUND, OVERLAY, SPRAY, WALL, GRADIENT -> true;
            default -> false; // erase/raise/lower/smooth/blend work from the world itself
        };
        if (needsPalette && palette.isEmpty()) {
            DraftEdit.msg(sp, "This brush has no blocks yet — sneak + right-click to open it and fill the palette.");
            return;
        }
        class_2248 maskBlock = c.mask.isEmpty() ? null : Compat.block(c.mask);
        // The protected list — blocks a stroke must never paint over, whatever else it does.
        java.util.Set<class_2248> shield = new java.util.HashSet<>();
        for (String id : c.protect) { class_2248 b = Compat.block(id); if (b != class_2246.field_10124) shield.add(b); }
        boolean admin = access().isAdmin(sp);
        int r = c.size;
        List<DraftEdit.Write> writes = new ArrayList<>();

        // Surface-mode Erase = restore the ground, not dig holes: clear everything above the
        // host's ground level, repaint the floor block (when the host defines one), and refill
        // any holes dug below it. With no ground concept, it clears a band around the aim point.
        // Ball-mode Erase still just clears to air.
        if (c.type == Type.ERASE && c.surface) {
            int top = center.method_10264() + Math.max(6, Math.min(r, 10));
            for (int dx = -r; dx <= r; dx++) for (int dz = -r; dz <= r; dz++) {
                double dist = Math.sqrt(dx * dx + dz * dz);
                if (dist > r + 0.45) continue;
                double chance = c.fade ? Math.max(0, 1.0 - (dist / (r + 0.5)) * (dist / (r + 0.5))) : 1.0;
                if (RNG.nextDouble() > chance) continue;
                int x = center.method_10263() + dx, z = center.method_10260() + dz;
                EditAccess.Ground ground = access().ground(level, x, z);
                int floorY = ground != null ? ground.y() : center.method_10264() - r - 1;
                for (int y = top; y > floorY; y--) {
                    class_2680 cur = level.method_8320(new class_2338(x, y, z));
                    if (cur.method_26215()) continue;
                    if (maskBlock != null && !cur.method_27852(maskBlock)) continue;
                    if (shield.contains(cur.method_26204())) continue;
                    if (DraftEdit.canEdit(sp, admin, x, y, z))
                        writes.add(new DraftEdit.Write(new class_2338(x, y, z), class_2246.field_10124.method_9564()));
                }
                if (maskBlock == null && ground != null && ground.surface() != null) {
                    class_2680 cur = level.method_8320(new class_2338(x, ground.y(), z));
                    if (!cur.equals(ground.surface()) && !shield.contains(cur.method_26204()) && DraftEdit.canEdit(sp, admin, x, ground.y(), z))
                        writes.add(new DraftEdit.Write(new class_2338(x, ground.y(), z), ground.surface()));
                    // refill anything dug out below the floor
                    for (int y = ground.y() - 1; y >= Math.max(access().minY(level), ground.y() - 8); y--) {
                        if (level.method_8320(new class_2338(x, y, z)).method_26215() && DraftEdit.canEdit(sp, admin, x, y, z))
                            writes.add(new DraftEdit.Write(new class_2338(x, y, z), class_2246.field_10566.method_9564()));
                    }
                }
            }
            DraftEdit.commit(sp, level, writes, "Restored ground —");
            return;
        }

        // ---- terraformers: raise / lower / smooth ----
        if (c.type == Type.RAISE || c.type == Type.LOWER || c.type == Type.SMOOTH) {
            terraform(sp, level, c, center, admin, r, palette, shield, writes);
            DraftEdit.commit(sp, level, writes, brushVerb(c.type));
            return;
        }

        // ---- gradient: palette in ORDER - radial on the ground, bottom-to-top on a wall ----
        if (c.type == Type.GRADIENT) {
            net.minecraft.class_2350 face = ((class_3965) hit).method_17780();
            int n = palette.size();
            if (face.method_10166().method_10179()) {
                net.minecraft.class_2350 inward = face.method_10153(), tangent = face.method_10170();
                for (int u = -r; u <= r; u++) for (int v = -r; v <= r; v++) {
                    if (Math.sqrt(u * u + v * v) > r + 0.45) continue;
                    double t = (v + r + 0.5) / (2 * r + 1) * n;              // 0 bottom -> n top
                    class_2680 chosen = palette.get(clampIdx((int) (t + (RNG.nextDouble() - 0.5) * 0.9), n));
                    class_2338 start = center.method_10079(face, 2).method_10079(tangent, u).method_10086(v);
                    for (int k = 0; k <= 5; k++) {
                        class_2338 wp = start.method_10079(inward, k);
                        class_2680 cur = level.method_8320(wp);
                        if (cur.method_26215() || !cur.method_26227().method_15769()) continue;
                        if (level.method_8320(wp.method_10093(face)).method_26215())
                            addWrite(writes, sp, level, admin, wp, cur, maskBlock, shield, palette, c, false, chosen);
                        break;
                    }
                }
            } else {
                for (int dx = -r; dx <= r; dx++) for (int dz = -r; dz <= r; dz++) {
                    double dist = Math.sqrt(dx * dx + dz * dz);
                    if (dist > r + 0.45) continue;
                    double t = dist / (r + 0.5) * n;                          // palette[0] center -> last at edge
                    class_2680 chosen = palette.get(clampIdx((int) (t + (RNG.nextDouble() - 0.5) * 0.9), n));
                    for (int y = center.method_10264(); y >= center.method_10264() - r - 2; y--) {
                        class_2338 wp = new class_2338(center.method_10263() + dx, y, center.method_10260() + dz);
                        class_2680 cur = level.method_8320(wp);
                        if (seesThrough(level, wp, cur) || !cur.method_26227().method_15769()) continue;
                        if (openAbove(level, wp))
                            addWrite(writes, sp, level, admin, wp, cur, maskBlock, shield, palette, c, true, chosen);
                        break;
                    }
                }
            }
            DraftEdit.commit(sp, level, writes, brushVerb(c.type));
            return;
        }

        // ---- blend: re-scatter the blocks already in the stroke - erases seams ----
        if (c.type == Type.BLEND) {
            List<class_2680> pool = new ArrayList<>();
            List<class_2338> targets = new ArrayList<>();
            for (int dx = -r; dx <= r; dx++) for (int dz = -r; dz <= r; dz++) {
                double dist = Math.sqrt(dx * dx + dz * dz);
                if (dist > r + 0.45) continue;
                if (c.surface) {
                    for (int y = center.method_10264(); y >= center.method_10264() - r - 2; y--) {
                        class_2338 wp = new class_2338(center.method_10263() + dx, y, center.method_10260() + dz);
                        class_2680 cur = level.method_8320(wp);
                        if (seesThrough(level, wp, cur) || !cur.method_26227().method_15769()) continue;
                        if (openAbove(level, wp)) { pool.add(cur); targets.add(wp); }
                        break;
                    }
                } else {
                    for (int dy = -r; dy <= r; dy++) {
                        if (Math.sqrt(dx * dx + dy * dy + dz * dz) > r + 0.45) continue;
                        class_2338 wp = center.method_10069(dx, dy, dz);
                        class_2680 cur = level.method_8320(wp);
                        if (!cur.method_26215() && cur.method_26227().method_15769()) { pool.add(cur); targets.add(wp); }
                    }
                }
            }
            if (pool.isEmpty()) { DraftEdit.msg(sp, "Nothing to blend here."); return; }
            for (class_2338 wp : targets) {
                double dist = Math.hypot(wp.method_10263() - center.method_10263(), wp.method_10260() - center.method_10260());
                double chance = c.density / 100.0;
                if (c.fade) chance *= Math.max(0, 1.0 - (dist / (r + 0.5)) * (dist / (r + 0.5)));
                if (RNG.nextDouble() > chance) continue;
                addWrite(writes, sp, level, admin, wp, level.method_8320(wp), maskBlock, shield, palette, c, false,
                        pool.get(RNG.nextInt(pool.size())));
            }
            DraftEdit.commit(sp, level, writes, brushVerb(c.type));
            return;
        }

        if (c.type == Type.WALL) {
            net.minecraft.class_2350 face = ((class_3965) hit).method_17780();
            if (!face.method_10166().method_10179()) { DraftEdit.msg(sp, "Aim at the SIDE of a wall to texture it."); return; }
            net.minecraft.class_2350 inward = face.method_10153(), tangent = face.method_10170();
            for (int u = -r; u <= r; u++) for (int v = -r; v <= r; v++) {
                double dist = Math.sqrt(u * u + v * v);
                if (dist > r + 0.45) continue;
                double chance = c.density / 100.0;
                if (c.fade) chance *= Math.max(0, 1.0 - (dist / (r + 0.5)) * (dist / (r + 0.5)));
                if (RNG.nextDouble() > chance) continue;
                // scan into the wall from just in front of it, so bumpy walls still get painted
                class_2338 start = center.method_10079(face, 2).method_10079(tangent, u).method_10086(v);
                for (int k = 0; k <= 5; k++) {
                    class_2338 wp = start.method_10079(inward, k);
                    class_2680 cur = level.method_8320(wp);
                    if (cur.method_26215() || !cur.method_26227().method_15769()) continue;
                    // a wall face is a face exposed to air on the side you aim at — the lawn in
                    // front of the wall fails this test, so the ground never gets wall texture
                    if (level.method_8320(wp.method_10093(face)).method_26215())
                        addWrite(writes, sp, level, admin, wp, cur, maskBlock, shield, palette, c, false, null);
                    break;
                }
            }
            DraftEdit.commit(sp, level, writes, brushVerb(c.type));
            return;
        }

        for (int dx = -r; dx <= r; dx++) for (int dz = -r; dz <= r; dz++) {
            double dist = Math.sqrt(dx * dx + dz * dz);
            if (dist > r + 0.45) continue;
            double chance = switch (c.type) {
                case SPLATTER -> c.density / 100.0;
                case SPRAY -> c.density / 100.0 * 0.2;
                default -> 1.0;
            };
            if (c.fade) chance *= Math.max(0, 1.0 - (dist / (r + 0.5)) * (dist / (r + 0.5)));
            boolean surfaceMode = c.surface || c.type == Type.OVERLAY;

            if (surfaceMode) {
                if (RNG.nextDouble() > chance) continue;
                // Splatter/spray never reach above the aimed block, and only paint OPEN surfaces —
                // so strokes can't stack onto blocks from earlier strokes and ratchet upward.
                boolean scatter = c.type == Type.SPLATTER || c.type == Type.SPRAY;
                int scanTop = scatter ? center.method_10264() : center.method_10264() + Math.min(r, 6) + 1;
                for (int y = scanTop; y >= center.method_10264() - r - 2; y--) {
                    class_2338 p = new class_2338(center.method_10263() + dx, y, center.method_10260() + dz);
                    class_2680 cur = level.method_8320(p);
                    if (seesThrough(level, p, cur) || !cur.method_26227().method_15769()) continue;
                    if (scatter && !openAbove(level, p)) break; // covered — skip column
                    addWrite(writes, sp, level, admin, p, cur, maskBlock, shield, palette, c, true, null);
                    break;
                }
            } else {
                for (int dy = -r; dy <= r; dy++) {
                    double d3 = Math.sqrt(dx * dx + dy * dy + dz * dz);
                    if (d3 > r + 0.45) continue;
                    double ballChance = switch (c.type) {
                        case SPLATTER -> c.density / 100.0;
                        case SPRAY -> c.density / 100.0 * 0.2;
                        default -> 1.0;
                    };
                    if (c.fade) ballChance *= Math.max(0, 1.0 - (d3 / (r + 0.5)) * (d3 / (r + 0.5)));
                    if (RNG.nextDouble() > ballChance) continue;
                    class_2338 p = center.method_10069(dx, dy, dz);
                    addWrite(writes, sp, level, admin, p, level.method_8320(p), maskBlock, shield, palette, c, false, null);
                }
            }
        }
        DraftEdit.commit(sp, level, writes, brushVerb(c.type));
    }

    /**
     * Air-like for surface scans: decorations that don't fill their block —
     * signs, lecterns, torches, flowers, snow layers — never cap a column.
     * The ground BENEATH a sign is the paintable surface; the sign survives
     * because writes replace the ground block without a neighbour update.
     */
    private static boolean seesThrough(class_3218 level, class_2338 pos, class_2680 state) {
        return state.method_26215() || !state.method_26234(level, pos);
    }

    /** A surface is open when what's above it is air or a see-through decoration. */
    private static boolean openAbove(class_3218 level, class_2338 pos) {
        class_2338 up = pos.method_10084();
        return seesThrough(level, up, level.method_8320(up));
    }

    private static void addWrite(List<DraftEdit.Write> writes, class_3222 sp, class_3218 level, boolean admin,
                                 class_2338 p, class_2680 cur, class_2248 maskBlock, java.util.Set<class_2248> shield,
                                 List<class_2680> palette, Config c, boolean surfaceMode, class_2680 forced) {
        if (!DraftEdit.canEdit(sp, admin, p.method_10263(), p.method_10264(), p.method_10260())) return;
        if (maskBlock != null && !cur.method_27852(maskBlock)) return;
        if (shield.contains(cur.method_26204())) return; // protected — never painted over (or decorated on top)
        if (c.type == Type.ERASE) {
            if (!cur.method_26215()) writes.add(new DraftEdit.Write(p, class_2246.field_10124.method_9564()));
            return;
        }
        class_2680 chosen = forced != null ? forced : palette.get(RNG.nextInt(palette.size()));
        // Half blocks (slabs, trapdoors, carpets…) go ON TOP of the surface — sinking them into
        // the ground punches trapdoor-holes in the lawn. Full blocks and stairs replace as before.
        if (surfaceMode && sitsOnTop(chosen)) {
            class_2338 top = p.method_10084();
            if (!level.method_8320(top).method_26215()) return;
            if (!DraftEdit.canEdit(sp, admin, top.method_10263(), top.method_10264(), top.method_10260())) return;
            // buttons, levers, grindstones default to wall attachment — on the ground they lie flat
            if (chosen.method_28498(net.minecraft.class_2341.field_11007))
                chosen = chosen.method_11657(net.minecraft.class_2341.field_11007,
                        net.minecraft.class_2738.field_12475);
            writes.add(new DraftEdit.Write(top, chosen));
        } else {
            writes.add(new DraftEdit.Write(p, chosen));
        }
    }

    /**
     * Anything that is not a full cube rests ON the surface; full cubes replace it. Asked of the
     * block itself (collision shape), so every block — vanilla or modded — sorts itself with no
     * per-block list. Stairs are the one agreed exception: they sink into the ground.
     */
    private static boolean sitsOnTop(class_2680 s) {
        if (s.method_26204() instanceof net.minecraft.class_2510) return false;
        return !s.method_26234(net.minecraft.class_2682.field_12294, class_2338.field_10980);
    }

    private static String brushVerb(Type t) {
        return switch (t) {
            case SPLATTER -> "Splattered"; case ROUND -> "Painted"; case OVERLAY -> "Overlaid";
            case SPRAY -> "Sprayed"; case ERASE -> "Erased"; case WALL -> "Textured";
            case RAISE -> "Raised"; case LOWER -> "Lowered"; case SMOOTH -> "Smoothed";
            case GRADIENT -> "Gradient"; case BLEND -> "Blended";
        } + " —";
    }

    /** Raise mounds terrain up, Lower dips it, Smooth averages each column toward its 3x3 mean. */
    private static void terraform(class_3222 sp, class_3218 level, Config c, class_2338 center,
                                  boolean admin, int r, List<class_2680> palette,
                                  java.util.Set<class_2248> shield, List<DraftEdit.Write> writes) {
        int peak = Math.max(1, r / 2);
        for (int dx = -r; dx <= r; dx++) for (int dz = -r; dz <= r; dz++) {
            double dist = Math.sqrt(dx * dx + dz * dz);
            if (dist > r + 0.45) continue;
            int x = center.method_10263() + dx, z = center.method_10260() + dz;
            int sy = surfaceY(level, x, z, center.method_10264(), r + 8);
            if (sy == Integer.MIN_VALUE) continue;
            class_2680 surf = level.method_8320(new class_2338(x, sy, z));
            if (shield.contains(surf.method_26204())) continue; // protected surface — leave the column alone

            int target = sy;
            if (c.type == Type.SMOOTH) {
                int sum = 0, cnt = 0;
                for (int nx = -1; nx <= 1; nx++) for (int nz = -1; nz <= 1; nz++) {
                    int ny = surfaceY(level, x + nx, z + nz, center.method_10264(), r + 8);
                    if (ny != Integer.MIN_VALUE) { sum += ny; cnt++; }
                }
                if (cnt > 0) target = Math.round((float) sum / cnt);
            } else {
                double fall = c.fade ? Math.max(0, 1.0 - (dist / (r + 0.5)) * (dist / (r + 0.5))) : 1.0;
                int amount = (int) Math.round(peak * fall);
                if (amount == 0) continue;
                target = c.type == Type.RAISE ? sy + amount : sy - amount;
            }

            if (target > sy) {                    // build the column up: filler below, cap on top
                for (int y = sy + 1; y <= target; y++) {
                    if (!DraftEdit.canEdit(sp, admin, x, y, z)) break;
                    class_2680 put = !palette.isEmpty() ? palette.get(RNG.nextInt(palette.size()))
                            : (y == target ? surf : class_2246.field_10566.method_9564());
                    writes.add(new DraftEdit.Write(new class_2338(x, y, z), put));
                }
            } else if (target < sy) {             // carve down, then re-cap the new surface
                for (int y = sy; y > target; y--)
                    if (!shield.contains(level.method_8320(new class_2338(x, y, z)).method_26204())
                            && DraftEdit.canEdit(sp, admin, x, y, z))
                        writes.add(new DraftEdit.Write(new class_2338(x, y, z), class_2246.field_10124.method_9564()));
                if (!shield.contains(level.method_8320(new class_2338(x, target, z)).method_26204())
                        && DraftEdit.canEdit(sp, admin, x, target, z)) {
                    class_2680 cap = !palette.isEmpty() ? palette.get(RNG.nextInt(palette.size())) : surf;
                    writes.add(new DraftEdit.Write(new class_2338(x, target, z), cap));
                }
            }
        }
    }

    /** Topmost solid, non-fluid block near refY, or MIN_VALUE if the window is all air. */
    private static int surfaceY(class_3218 level, int x, int z, int refY, int window) {
        for (int y = refY + window; y >= refY - window; y--) {
            class_2680 s = level.method_8320(new class_2338(x, y, z));
            if (!s.method_26215() && s.method_26227().method_15769()) return y;
        }
        return Integer.MIN_VALUE;
    }

    private static int clampIdx(int i, int n) { return Math.max(0, Math.min(n - 1, i)); }

    // ---- particle previews ---------------------------------------------------

    private static void previewRing(class_3222 sp, class_3218 level, int r) {
        class_239 hit = sp.method_5745(REACH, 0f, false);
        if (hit.method_17783() != class_239.class_240.field_1332) return;
        class_2338 c = ((class_3965) hit).method_17777();
        int points = Math.max(12, r * 6);
        for (int i = 0; i < points; i++) {
            double a = 2 * Math.PI * i / points;
            level.method_14166(sp, class_2398.field_11207, true, // 1.21.1: one boolean (force); 26.x has two
                    c.method_10263() + 0.5 + Math.cos(a) * (r + 0.5), c.method_10264() + 1.1, c.method_10260() + 0.5 + Math.sin(a) * (r + 0.5),
                    1, 0, 0, 0, 0);
        }
    }

    /** Corner 1 → corner 2 box edges while the editor wand is in hand. */
    private static void outlineSelection(class_3222 sp, class_3218 level) {
        class_2338 p1 = DraftEdit.POS1.get(sp.method_5667()), p2 = DraftEdit.POS2.get(sp.method_5667());
        if (p1 == null || p2 == null) return;
        double x1 = Math.min(p1.method_10263(), p2.method_10263()), x2 = Math.max(p1.method_10263(), p2.method_10263()) + 1;
        double y1 = Math.min(p1.method_10264(), p2.method_10264()), y2 = Math.max(p1.method_10264(), p2.method_10264()) + 1;
        double z1 = Math.min(p1.method_10260(), p2.method_10260()), z2 = Math.max(p1.method_10260(), p2.method_10260()) + 1;
        double step = 1.5;
        for (double x = x1; x <= x2; x += step) for (double[] yz : new double[][]{{y1,z1},{y1,z2},{y2,z1},{y2,z2}})
            level.method_14166(sp, class_2398.field_11211, true,x, yz[0], yz[1], 1, 0, 0, 0, 0);
        for (double y = y1; y <= y2; y += step) for (double[] xz : new double[][]{{x1,z1},{x1,z2},{x2,z1},{x2,z2}})
            level.method_14166(sp, class_2398.field_11211, true,xz[0], y, xz[1], 1, 0, 0, 0, 0);
        for (double z = z1; z <= z2; z += step) for (double[] xy : new double[][]{{x1,y1},{x1,y2},{x2,y1},{x2,y2}})
            level.method_14166(sp, class_2398.field_11211, true,xy[0], xy[1], z, 1, 0, 0, 0, 0);
    }
}
