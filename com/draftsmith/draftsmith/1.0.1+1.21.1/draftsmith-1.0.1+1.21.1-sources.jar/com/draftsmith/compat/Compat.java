package com.draftsmith.compat;

import net.minecraft.class_1767;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2625;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_7923;

/**
 * The version seam. Everything that tends to change between Minecraft versions funnels through
 * this package, so porting to another version means re-implementing THIS class — not hunting the
 * codebase. Known differences are noted per method.
 */
public final class Compat {
    private Compat() {}

    // ---- registry lookups --------------------------------------------------
    // 1.21.1: ResourceLocation + Registry.get. 26.x: Identifier + Registry.getValue.
    // Always address blocks/items by REGISTRY ID in shared code — 26.2 moved the per-color
    // constants (LIME_CONCRETE etc.) into ColorCollection, but ids never changed.

    /** Raw block lookup by registry id (returns the registry default on unknown ids). */
    public static class_2248 block(String id) {
        return class_7923.field_41175.method_10223(class_2960.method_60654(id));
    }

    /** Raw item lookup by registry id (returns the registry default on unknown ids). */
    public static class_1792 item(String id) {
        return class_7923.field_41178.method_10223(class_2960.method_60654(id));
    }

    // ---- giving items (wand / brush handouts) -------------------------------
    // 26.1/26.2 & 1.21.1: placeItemBackInInventory(stack). 26.3: takes a Prediction arg
    // (SERVER_ONLY for server-initiated gives — there is no client prediction to reconcile).

    /** Put {@code stack} into the player's inventory (hotbar first, drops at their feet if full). */
    public static void giveItem(net.minecraft.class_3222 p, net.minecraft.class_1799 stack) {
        p.method_31548().method_7398(stack);
    }

    // ---- chat click events (/draft help) -----------------------------------
    // 1.21.1: new ClickEvent(Action.SUGGEST_COMMAND, s). 26.x: ClickEvent.SuggestCommand record.

    /** A click event that puts {@code command} into the player's chat bar. */
    public static net.minecraft.class_2558 suggestCommand(String command) {
        return new net.minecraft.class_2558(
                net.minecraft.class_2558.class_2559.field_11745, command);
    }

    // ---- sign text (measuring tape numbers) --------------------------------
    // SignText API is stable since 1.20, but setText/getText signatures have moved before.

    /** Write {@code text} on both faces of the sign at pos — black dye + glow ink, waxed. */
    public static void labelSign(class_3218 level, class_2338 pos, String text) {
        if (level.method_8321(pos) instanceof class_2625 sbe) {
            class_2561 c = class_2561.method_43470(text);
            sbe.method_49840(sbe.method_49843(true).method_49857(1, c)
                    .method_49862(class_1767.field_7963).method_49867(true), true);
            sbe.method_49840(sbe.method_49843(false).method_49857(1, c)
                    .method_49862(class_1767.field_7963).method_49867(true), false);
            sbe.method_49849(true); // nobody should be able to edit the numbers
            sbe.method_5431();
            level.method_8413(pos, level.method_8320(pos), level.method_8320(pos), class_2248.field_31028);
        }
    }
}
