package com.draftsmith.edit;

import com.draftsmith.api.DraftSmithApi;
import com.draftsmith.api.EditAccess;
import com.draftsmith.compat.Compat;

import net.fabricmc.fabric.api.event.player.AttackBlockCallback;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.commands.arguments.blocks.BlockInput;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.component.DataComponents;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.EntityBlock;
import net.minecraft.world.level.block.state.BlockState;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.function.BiPredicate;

/**
 * "WorldEdit-lite", jailed by the host's {@link EditAccess}. Pick two corners (commands or the
 * editor wand), then set or replace — but every block written is checked against the access
 * provider first, so the edit physically cannot escape the area the player may build in. Each
 * edit snapshots the blocks it changes so undo can reverse it. Admins are unclamped but the
 * provider still has the final word per block.
 */
public final class DraftEdit {
    private static final String LEGACY_WAND_NAME = "plot_editor";     // pre-0.4.0 FabricPlots wands
    private static final String WAND_TAG = "draftsmith_wand";         // custom-data marker — survives anvil renames
    private static final String LEGACY_WAND_TAG = "fabricplots_wand"; // 0.4.0 FabricPlots wands
    private static final net.minecraft.world.item.Item WAND_ITEM = Items.WOODEN_AXE;
    private static final long MAX_SELECTION_SCAN = 1_000_000L;
    private static final int UNDO_DEPTH = 10;      // edits kept per player — brushes invite rapid strokes

    private static final BlockState AIR = Blocks.AIR.defaultBlockState();

    static final Map<UUID, BlockPos> POS1 = new HashMap<>(); // package-private: selection outline particles
    static final Map<UUID, BlockPos> POS2 = new HashMap<>();
    private static final Map<UUID, Boolean> NEXT_IS_POS2 = new HashMap<>(); // wand alternation
    public record Snapshot(BlockPos pos, BlockState old) {} // public: DraftShapes/DraftMeasure snapshot too
    private static final Map<UUID, Deque<List<Snapshot>>> UNDO = new HashMap<>();
    private static final Map<UUID, Deque<List<Snapshot>>> REDO = new HashMap<>();

    private record ClipBlock(int dx, int dy, int dz, BlockState state) {} // clipboard, relative to copy origin
    public record Write(BlockPos pos, BlockState state) {} // public: DraftBrush builds strokes
    private static final Map<UUID, List<ClipBlock>> CLIPBOARD = new HashMap<>();

    // Random-texture toggle: when ON, every written block rolls from the BLOCK items in the
    // player's hotbar (duplicate slots weight the mix). Session-only.
    private static final Set<UUID> RANDOM_TEXTURE = new HashSet<>();
    private static final java.util.Random RNG = new java.util.Random();

    private DraftEdit() {}

    static EditAccess access() { return DraftSmithApi.access(); }

    // ---- the editor wand (a tagged wooden axe) ----

    public static ItemStack createWand() {
        ItemStack s = new ItemStack(WAND_ITEM);
        s.set(DataComponents.CUSTOM_NAME, Component.literal("Editor Wand"));
        // Data marker (same scheme as DraftBrush) so an anvil rename can't break the wand.
        CompoundTag root = new CompoundTag();
        root.put(WAND_TAG, new CompoundTag());
        s.set(DataComponents.CUSTOM_DATA, CustomData.of(root));
        return s;
    }

    public static boolean isWand(ItemStack s) {
        if (s.isEmpty() || s.getItem() != WAND_ITEM) return false;
        CustomData d = s.get(DataComponents.CUSTOM_DATA);
        if (d != null) {
            CompoundTag t = d.copyTag();
            if (t.contains(WAND_TAG) || t.contains(LEGACY_WAND_TAG)) return true;
        }
        Component n = s.get(DataComponents.CUSTOM_NAME); // legacy wands (pre-0.4.0) carry only the name
        return n != null && LEGACY_WAND_NAME.equals(n.getString());
    }

    public static void register() {
        // The wand never breaks blocks — left-click is swallowed.
        AttackBlockCallback.EVENT.register((player, world, hand, pos, dir) -> {
            if (!access().isActiveDimension(world)) return InteractionResult.PASS;
            return isWand(player.getItemInHand(hand)) ? InteractionResult.FAIL : InteractionResult.PASS;
        });
        // Right-click sets a corner, alternating 1 → 2 → 1. SUCCESS so the client forwards the click.
        UseBlockCallback.EVENT.register((player, world, hand, hit) -> {
            if (!access().isActiveDimension(world)) return InteractionResult.PASS;
            if (!isWand(player.getItemInHand(hand))) return InteractionResult.PASS;
            if (player instanceof ServerPlayer sp) {
                if (!access().canUse(sp, EditAccess.Tool.WAND)) return InteractionResult.PASS;
                boolean second = NEXT_IS_POS2.getOrDefault(sp.getUUID(), false);
                mark(sp, hit.getBlockPos(), !second);
                NEXT_IS_POS2.put(sp.getUUID(), !second);
            }
            return InteractionResult.SUCCESS;
        });
    }

    private static void mark(ServerPlayer sp, BlockPos pos, boolean isPos1) {
        (isPos1 ? POS1 : POS2).put(sp.getUUID(), pos.immutable());
        msg(sp, "Corner " + (isPos1 ? "1" : "2") + " set at " + xyz(pos) + ".");
    }

    /** The block the player is holding (default state), or null if their main hand isn't a block. */
    public static BlockState heldBlock(ServerPlayer sp) {
        return sp.getMainHandItem().getItem() instanceof net.minecraft.world.item.BlockItem bi
                ? bi.getBlock().defaultBlockState() : null;
    }

    public static void setPos1(ServerPlayer sp) { POS1.put(sp.getUUID(), sp.blockPosition().immutable()); msg(sp, "Corner 1 set at " + xyz(sp.blockPosition()) + "."); }
    public static void setPos2(ServerPlayer sp) { POS2.put(sp.getUUID(), sp.blockPosition().immutable()); msg(sp, "Corner 2 set at " + xyz(sp.blockPosition()) + "."); }

    // ---- random texture --------------------------------------------------

    /** Toggle hotbar-random texturing for this player. Returns the new state. */
    public static boolean toggleRandomTexture(ServerPlayer sp) {
        UUID id = sp.getUUID();
        if (RANDOM_TEXTURE.remove(id)) return false;
        RANDOM_TEXTURE.add(id);
        return true;
    }

    public static boolean isRandomTexture(ServerPlayer sp) {
        return RANDOM_TEXTURE.contains(sp.getUUID());
    }

    // Re-entrancy guard for the hand-placement randomizer (main server thread only).
    private static boolean placingRandom = false;

    /**
     * Hand-placement half of the random-texture toggle (called from RandomTexturePlaceMixin):
     * with the toggle ON in an active dimension, placing a block by hand rolls the block from the
     * hotbar instead — lay a path without scrolling. Returns null to let vanilla placement run.
     * In survival the consumed item is moved to the block actually placed, so cheap blocks can't
     * be converted into rare ones.
     */
    public static InteractionResult randomPlace(net.minecraft.world.item.BlockItem self,
                                                net.minecraft.world.item.context.BlockPlaceContext ctx) {
        if (placingRandom) return null;
        if (!(ctx.getLevel() instanceof ServerLevel level)) return null; // server side decides
        if (!access().isActiveDimension(level)) return null;
        if (!(ctx.getPlayer() instanceof ServerPlayer sp)) return null;
        if (!access().canUse(sp)) return null;
        if (!isRandomTexture(sp)) return null;
        List<net.minecraft.world.item.BlockItem> pool = new ArrayList<>();
        for (int i = 0; i < 9; i++) {
            ItemStack s = sp.getInventory().getItem(i);
            if (!s.isEmpty() && s.getItem() instanceof net.minecraft.world.item.BlockItem bi) pool.add(bi);
        }
        if (pool.isEmpty()) return null;
        net.minecraft.world.item.BlockItem rolled = pool.get(RNG.nextInt(pool.size()));
        if (rolled == self) return null; // rolled the held block — vanilla placement is already right

        ItemStack held = ctx.getItemInHand();
        int before = held.getCount();
        InteractionResult result;
        placingRandom = true;
        try { result = rolled.place(ctx); } finally { placingRandom = false; }
        if (result.consumesAction() && !sp.getAbilities().instabuild && held.getCount() < before) {
            held.grow(1); // vanilla took it from the held stack — charge the rolled stack instead
            for (int i = 0; i < 9; i++) {
                ItemStack s = sp.getInventory().getItem(i);
                if (s != held && !s.isEmpty() && s.getItem() == rolled) { s.shrink(1); break; }
            }
        }
        return result;
    }

    /**
     * The material source for an edit: the held block — or, with random texture ON, a fresh roll
     * from the hotbar's block items per block written. Duplicate hotbar slots weight the mix.
     */
    static java.util.function.Supplier<BlockState> materials(ServerPlayer sp, BlockState held) { // package-private: DraftShapes builds too
        if (!isRandomTexture(sp)) return () -> held;
        List<BlockState> pool = new ArrayList<>();
        for (int i = 0; i < 9; i++) {
            ItemStack s = sp.getInventory().getItem(i);
            if (!s.isEmpty() && s.getItem() instanceof net.minecraft.world.item.BlockItem bi
                    && !(bi.getBlock() instanceof EntityBlock))
                pool.add(bi.getBlock().defaultBlockState());
        }
        if (pool.isEmpty()) return () -> held;
        return () -> pool.get(RNG.nextInt(pool.size()));
    }

    // ---- operations ------------------------------------------------------

    public static int set(ServerPlayer sp, ServerLevel level, BlockState state) {
        if (blockEntityState(state)) return rejectBlockEntity(sp);
        return applyEdit(sp, level, (lvl, p) -> true, materials(sp, state), "Set");
    }

    public static int replace(ServerPlayer sp, ServerLevel level, BlockInput from, BlockState to) {
        if (blockEntityState(to)) return rejectBlockEntity(sp);
        return applyEdit(sp, level, from::test, materials(sp, to), "Replaced");
    }

    private static int applyEdit(ServerPlayer sp, ServerLevel level, BiPredicate<ServerLevel, BlockPos> include,
                                 BlockState newState, String verb) {
        return applyEdit(sp, level, include, () -> newState, verb);
    }

    private static int applyEdit(ServerPlayer sp, ServerLevel level, BiPredicate<ServerLevel, BlockPos> include,
                                 java.util.function.Supplier<BlockState> material, String verb) {
        UUID id = sp.getUUID();
        BlockPos p1 = POS1.get(id), p2 = POS2.get(id);
        if (p1 == null || p2 == null) { msg(sp, "Set both corners first — /draft pos1 and /draft pos2, or grab the wand with /draft wand."); return 0; }
        if (selectionVolume(p1, p2, level) > MAX_SELECTION_SCAN) {
            msg(sp, "That selection is too large to scan safely — narrow your corners first.");
            return 0;
        }
        final boolean admin = access().isAdmin(sp);
        final int x1 = Math.min(p1.getX(), p2.getX()), x2 = Math.max(p1.getX(), p2.getX());
        final int z1 = Math.min(p1.getZ(), p2.getZ()), z2 = Math.max(p1.getZ(), p2.getZ());
        final int y1 = Math.max(access().minY(level), Math.min(p1.getY(), p2.getY()));
        final int y2 = Math.min(access().maxY(level), Math.max(p1.getY(), p2.getY()));

        List<Write> writes = new ArrayList<>();
        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
        for (int x = x1; x <= x2; x++) {
            for (int z = z1; z <= z2; z++) {
                for (int y = y1; y <= y2; y++) {
                    if (!access().canEdit(sp, admin, x, y, z)) continue;    // the jail — asked per block
                    pos.set(x, y, z);
                    if (!include.test(level, pos)) continue;                // replace: only matching blocks
                    writes.add(new Write(pos.immutable(), material.get()));
                    if (writes.size() > DraftLimits.MAX_BLOCKS) { msg(sp, "That's over " + DraftLimits.MAX_BLOCKS + " blocks — narrow your selection."); return 0; }
                }
            }
        }
        return commit(sp, level, writes, verb);
    }

    public static int undo(ServerPlayer sp, ServerLevel level) {
        return step(sp, level, UNDO, REDO, "Nothing to undo.", "Undone");
    }

    public static int redo(ServerPlayer sp, ServerLevel level) {
        return step(sp, level, REDO, UNDO, "Nothing to redo.", "Redone");
    }

    /** Pop one edit off {@code from}, restore those blocks, and push the pre-restore state onto {@code to}. */
    private static int step(ServerPlayer sp, ServerLevel level, Map<UUID, Deque<List<Snapshot>>> from,
                            Map<UUID, Deque<List<Snapshot>>> to, String empty, String verb) {
        Deque<List<Snapshot>> stack = from.get(sp.getUUID());
        if (stack == null || stack.isEmpty()) { msg(sp, empty); return 0; }
        List<Snapshot> edit = stack.peek();
        boolean admin = access().isAdmin(sp);
        for (Snapshot s : edit) {
            BlockPos pos = s.pos();
            if (!canEdit(sp, admin, pos.getX(), pos.getY(), pos.getZ())
                    || unsafeWrite(level, pos, s.old())) {
                msg(sp, "Undo/redo stopped: access changed or the edit touches a container/sign.");
                return 0;
            }
        }
        stack.pop();
        List<Snapshot> inverse = new ArrayList<>(edit.size());
        for (Snapshot s : edit) {
            inverse.add(new Snapshot(s.pos(), level.getBlockState(s.pos())));
            level.setBlock(s.pos(), s.old(), Block.UPDATE_CLIENTS);
        }
        to.computeIfAbsent(sp.getUUID(), k -> new ArrayDeque<>()).push(inverse);
        msg(sp, verb + " — " + edit.size() + " block" + (edit.size() == 1 ? "" : "s") + ".");
        return 1;
    }

    // ---- clipboard: copy / cut / paste / stack / move --------------------

    public static int copy(ServerPlayer sp, ServerLevel level) {
        int n = doCopy(sp, level);
        if (n < 0) return 0;
        msg(sp, "Copied " + n + " blocks. Aim (or stand) where you want it and /draft paste.");
        return 1;
    }

    public static int cut(ServerPlayer sp, ServerLevel level) {
        if (doCopy(sp, level) < 0) return 0;
        return applyEdit(sp, level, (l, p) -> true, AIR, "Cut"); // copy, then clear the selection (clamped)
    }

    /** Capture the selection into the player's clipboard, relative to their position. -1 on error. */
    private static int doCopy(ServerPlayer sp, ServerLevel level) {
        UUID id = sp.getUUID();
        BlockPos p1 = POS1.get(id), p2 = POS2.get(id);
        if (p1 == null || p2 == null) { msg(sp, "Set both corners first."); return -1; }
        if (selectionVolume(p1, p2, level) > DraftLimits.MAX_BLOCKS) {
            msg(sp, "Selection too big to copy (over " + DraftLimits.MAX_BLOCKS + ").");
            return -1;
        }
        BlockPos origin = sp.blockPosition();
        int x1 = Math.min(p1.getX(), p2.getX()), x2 = Math.max(p1.getX(), p2.getX());
        int z1 = Math.min(p1.getZ(), p2.getZ()), z2 = Math.max(p1.getZ(), p2.getZ());
        int y1 = Math.max(access().minY(level), Math.min(p1.getY(), p2.getY()));
        int y2 = Math.min(access().maxY(level), Math.max(p1.getY(), p2.getY()));
        List<ClipBlock> clip = new ArrayList<>();
        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
        for (int x = x1; x <= x2; x++) for (int z = z1; z <= z2; z++) for (int y = y1; y <= y2; y++) {
            pos.set(x, y, z);
            if (level.getBlockEntity(pos) != null) {
                msg(sp, "Copy stopped: selections containing containers or signs are not supported safely.");
                return -1;
            }
            clip.add(new ClipBlock(x - origin.getX(), y - origin.getY(), z - origin.getZ(), level.getBlockState(pos)));
            if (clip.size() > DraftLimits.MAX_BLOCKS) { msg(sp, "Selection too big to copy (over " + DraftLimits.MAX_BLOCKS + ")."); return -1; }
        }
        CLIPBOARD.put(id, clip);
        return clip.size();
    }

    public static int paste(ServerPlayer sp, ServerLevel level) {
        List<ClipBlock> clip = CLIPBOARD.get(sp.getUUID());
        if (clip == null || clip.isEmpty()) { msg(sp, "Nothing to paste — /draft copy first."); return 0; }
        boolean admin = access().isAdmin(sp);
        // Land the paste where the player is AIMING (same raycast as the brushes) — one above the
        // hit block, so aiming at the ground behaves exactly like standing there. No block in range
        // falls back to the old behavior: paste at your feet.
        BlockPos origin = sp.blockPosition();
        net.minecraft.world.phys.HitResult hit = sp.pick(30, 0f, false);
        if (hit.getType() == net.minecraft.world.phys.HitResult.Type.BLOCK)
            origin = ((net.minecraft.world.phys.BlockHitResult) hit).getBlockPos().above();
        List<Write> writes = new ArrayList<>();
        int skipped = 0;
        for (ClipBlock c : clip) {
            if (c.state().isAir()) continue; // stamp solids only, don't erase the surroundings
            int x = origin.getX() + c.dx(), y = origin.getY() + c.dy(), z = origin.getZ() + c.dz();
            if (!canEdit(sp, admin, x, y, z)) { skipped++; continue; }
            writes.add(new Write(new BlockPos(x, y, z), c.state()));
        }
        int r = commit(sp, level, writes, "Pasted");
        if (r == 1 && skipped > 0) msg(sp, "(" + skipped + " blocks skipped — outside " + access().editableAreaName() + ".)");
        return r;
    }

    public static int stack(ServerPlayer sp, ServerLevel level, int count) {
        UUID id = sp.getUUID();
        BlockPos p1 = POS1.get(id), p2 = POS2.get(id);
        if (p1 == null || p2 == null) { msg(sp, "Set both corners first."); return 0; }
        long volume = selectionVolume(p1, p2, level);
        if (volume > MAX_SELECTION_SCAN || DraftLimits.exceeds(volume, count, DraftLimits.MAX_BLOCKS)) return rejectLarge(sp);
        boolean admin = access().isAdmin(sp);
        Direction dir = sp.getDirection();
        int x1 = Math.min(p1.getX(), p2.getX()), x2 = Math.max(p1.getX(), p2.getX());
        int z1 = Math.min(p1.getZ(), p2.getZ()), z2 = Math.max(p1.getZ(), p2.getZ());
        int y1 = Math.max(access().minY(level), Math.min(p1.getY(), p2.getY()));
        int y2 = Math.min(access().maxY(level), Math.max(p1.getY(), p2.getY()));
        int span = switch (dir.getAxis()) { case X -> x2 - x1 + 1; case Z -> z2 - z1 + 1; default -> y2 - y1 + 1; };
        List<Write> writes = new ArrayList<>();
        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
        for (int i = 1; i <= count; i++) {
            int ox = dir.getStepX() * span * i, oy = dir.getStepY() * span * i, oz = dir.getStepZ() * span * i;
            for (int x = x1; x <= x2; x++) for (int z = z1; z <= z2; z++) for (int y = y1; y <= y2; y++) {
                pos.set(x, y, z);
                BlockState src = level.getBlockState(pos); // source region never overlaps a destination
                int nx = x + ox, ny = y + oy, nz = z + oz;
                if (!canEdit(sp, admin, nx, ny, nz)) continue;
                writes.add(new Write(new BlockPos(nx, ny, nz), src));
            }
        }
        return commit(sp, level, writes, "Stacked x" + count + " →");
    }

    public static int move(ServerPlayer sp, ServerLevel level, int count) {
        UUID id = sp.getUUID();
        BlockPos p1 = POS1.get(id), p2 = POS2.get(id);
        if (p1 == null || p2 == null) { msg(sp, "Set both corners first."); return 0; }
        long volume = selectionVolume(p1, p2, level);
        if (volume > MAX_SELECTION_SCAN || DraftLimits.exceeds(volume, 2, DraftLimits.MAX_BLOCKS)) return rejectLarge(sp);
        boolean admin = access().isAdmin(sp);
        Direction dir = sp.getDirection();
        int ox = dir.getStepX() * count, oy = dir.getStepY() * count, oz = dir.getStepZ() * count;
        int x1 = Math.min(p1.getX(), p2.getX()), x2 = Math.max(p1.getX(), p2.getX());
        int z1 = Math.min(p1.getZ(), p2.getZ()), z2 = Math.max(p1.getZ(), p2.getZ());
        int y1 = Math.max(access().minY(level), Math.min(p1.getY(), p2.getY()));
        int y2 = Math.min(access().maxY(level), Math.max(p1.getY(), p2.getY()));
        List<Write> clears = new ArrayList<>(), places = new ArrayList<>();
        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
        for (int x = x1; x <= x2; x++) for (int z = z1; z <= z2; z++) for (int y = y1; y <= y2; y++) {
            if (!canEdit(sp, admin, x, y, z)) continue; // only move blocks you own
            pos.set(x, y, z);
            BlockState src = level.getBlockState(pos);
            clears.add(new Write(new BlockPos(x, y, z), AIR));
            int nx = x + ox, ny = y + oy, nz = z + oz;
            if (canEdit(sp, admin, nx, ny, nz)) places.add(new Write(new BlockPos(nx, ny, nz), src));
        }
        List<Write> writes = new ArrayList<>(clears); // clear first, then place (place wins on overlap)
        writes.addAll(places);
        return commit(sp, level, writes, "Moved");
    }

    // ---- shapes ----------------------------------------------------------

    public static int walls(ServerPlayer sp, ServerLevel level, BlockState state) {
        if (blockEntityState(state)) return rejectBlockEntity(sp);
        UUID id = sp.getUUID();
        BlockPos p1 = POS1.get(id), p2 = POS2.get(id);
        if (p1 == null || p2 == null) { msg(sp, "Set both corners first."); return 0; }
        if (selectionVolume(p1, p2, level) > MAX_SELECTION_SCAN) return rejectLarge(sp);
        boolean admin = access().isAdmin(sp);
        int x1 = Math.min(p1.getX(), p2.getX()), x2 = Math.max(p1.getX(), p2.getX());
        int z1 = Math.min(p1.getZ(), p2.getZ()), z2 = Math.max(p1.getZ(), p2.getZ());
        int y1 = Math.max(access().minY(level), Math.min(p1.getY(), p2.getY()));
        int y2 = Math.min(access().maxY(level), Math.max(p1.getY(), p2.getY()));
        long dx = (long) x2 - x1 + 1L, dz = (long) z2 - z1 + 1L, dy = Math.max(0L, (long) y2 - y1 + 1L);
        long perimeter = dx == 1 || dz == 1 ? dx * dz : 2L * dx + 2L * dz - 4L;
        if (DraftLimits.exceeds(perimeter, dy, DraftLimits.MAX_BLOCKS)) return rejectLarge(sp);
        var mat = materials(sp, state);
        List<Write> writes = new ArrayList<>();
        for (int x = x1; x <= x2; x++) for (int z = z1; z <= z2; z++) {
            if (x != x1 && x != x2 && z != z1 && z != z2) continue; // perimeter only
            for (int y = y1; y <= y2; y++) if (canEdit(sp, admin, x, y, z)) writes.add(new Write(new BlockPos(x, y, z), mat.get()));
        }
        return commit(sp, level, writes, "Built walls —");
    }

    public static int sphere(ServerPlayer sp, ServerLevel level, BlockState state, int r, boolean hollow) {
        if (blockEntityState(state)) return rejectBlockEntity(sp);
        double outerEstimate = r + 0.5, innerEstimate = Math.max(0, r - 0.5);
        double estimatedWrites = 4.0 / 3.0 * Math.PI * (outerEstimate * outerEstimate * outerEstimate
                - (hollow ? innerEstimate * innerEstimate * innerEstimate : 0));
        if (estimatedWrites > DraftLimits.MAX_BLOCKS) return rejectLarge(sp);
        boolean admin = access().isAdmin(sp);
        BlockPos c = sp.blockPosition();
        double outer = r + 0.5, inner = r - 0.5;
        var mat = materials(sp, state);
        List<Write> writes = new ArrayList<>();
        for (int dx = -r; dx <= r; dx++) for (int dy = -r; dy <= r; dy++) for (int dz = -r; dz <= r; dz++) {
            double dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
            if (dist > outer || (hollow && dist < inner)) continue;
            int x = c.getX() + dx, y = c.getY() + dy, z = c.getZ() + dz;
            if (canEdit(sp, admin, x, y, z)) writes.add(new Write(new BlockPos(x, y, z), mat.get()));
        }
        return commit(sp, level, writes, hollow ? "Hollow sphere —" : "Sphere —");
    }

    public static int cylinder(ServerPlayer sp, ServerLevel level, BlockState state, int r, int height) {
        if (blockEntityState(state)) return rejectBlockEntity(sp);
        double outerEstimate = r + 0.5;
        if (Math.PI * outerEstimate * outerEstimate * height > DraftLimits.MAX_BLOCKS) return rejectLarge(sp);
        boolean admin = access().isAdmin(sp);
        BlockPos c = sp.blockPosition();
        double rr = (r + 0.5) * (r + 0.5);
        var mat = materials(sp, state);
        List<Write> writes = new ArrayList<>();
        for (int dx = -r; dx <= r; dx++) for (int dz = -r; dz <= r; dz++) {
            if (dx * dx + dz * dz > rr) continue;
            for (int dy = 0; dy < height; dy++) {
                int x = c.getX() + dx, y = c.getY() + dy, z = c.getZ() + dz;
                if (canEdit(sp, admin, x, y, z)) writes.add(new Write(new BlockPos(x, y, z), mat.get()));
            }
        }
        return commit(sp, level, writes, "Cylinder —");
    }

    // ---- shared lookups --------------------------------------------------

    /** Registry-ID lookup via the version seam — colored blocks stay identical across branches. */
    static Block blockById(String id) { // package-private: DraftMeasure's tape blocks
        return Compat.block(id);
    }

    /** Snapshot (deduped, original states), apply all writes, push one undo entry. */
    public static int commit(ServerPlayer sp, ServerLevel level, List<Write> writes, String verb) {
        if (writes.isEmpty()) { msg(sp, "Nothing to change — make sure it lands on " + access().editableAreaName() + "."); return 0; }
        if (writes.size() > DraftLimits.MAX_BLOCKS) { msg(sp, "That's over " + DraftLimits.MAX_BLOCKS + " blocks — use a smaller selection or count."); return 0; }
        boolean admin = access().isAdmin(sp);
        Set<BlockPos> seen = new HashSet<>();
        List<Snapshot> snaps = new ArrayList<>();
        List<Write> safe = new ArrayList<>(writes.size());
        int skipped = 0;
        for (Write w : writes) {
            BlockPos pos = w.pos();
            if (!canEdit(sp, admin, pos.getX(), pos.getY(), pos.getZ()) || unsafeWrite(level, pos, w.state())) {
                skipped++;
                continue;
            }
            safe.add(w);
            if (seen.add(pos)) snaps.add(new Snapshot(pos, level.getBlockState(pos)));
        }
        if (safe.isEmpty()) {
            msg(sp, "Nothing changed — access changed or the edit touches a container/sign.");
            return 0;
        }
        for (Write w : safe) level.setBlock(w.pos(), w.state(), Block.UPDATE_CLIENTS);
        pushUndo(sp.getUUID(), snaps);
        msg(sp, verb + " " + safe.size() + " blocks. /draft undo to revert."
                + (skipped > 0 ? " (" + skipped + " unsafe or no-longer-authorized writes skipped.)" : ""));
        return 1;
    }

    /** Can this player write at x/y/z? Delegates to the host's access provider — the jail. */
    public static boolean canEdit(ServerPlayer sp, boolean admin, int x, int y, int z) {
        return access().canEdit(sp, admin, x, y, z);
    }

    static boolean unsafeWrite(ServerLevel level, BlockPos pos, BlockState state) {
        return blockEntityState(state) || level.getBlockEntity(pos) != null;
    }

    static boolean blockEntityState(BlockState state) {
        return state.getBlock() instanceof EntityBlock;
    }

    private static long selectionVolume(BlockPos p1, BlockPos p2, ServerLevel level) {
        long dx = Math.abs((long) p1.getX() - p2.getX()) + 1L;
        long dz = Math.abs((long) p1.getZ() - p2.getZ()) + 1L;
        int y1 = Math.max(access().minY(level), Math.min(p1.getY(), p2.getY()));
        int y2 = Math.min(access().maxY(level), Math.max(p1.getY(), p2.getY()));
        long dy = Math.max(0L, (long) y2 - y1 + 1L);
        if (DraftLimits.exceeds(dx, dz, Long.MAX_VALUE)) return Long.MAX_VALUE;
        long area = dx * dz;
        return DraftLimits.exceeds(area, dy, Long.MAX_VALUE) ? Long.MAX_VALUE : area * dy;
    }

    static int rejectBlockEntity(ServerPlayer sp) {
        msg(sp, "Containers and signs are not supported by editor history; place them by hand.");
        return 0;
    }

    static int rejectLarge(ServerPlayer sp) {
        msg(sp, "That operation is too large to run safely; use a smaller selection, size, height, or count.");
        return 0;
    }

    private static void pushUndo(UUID id, List<Snapshot> snaps) {
        Deque<List<Snapshot>> stack = UNDO.computeIfAbsent(id, k -> new ArrayDeque<>());
        stack.push(snaps);
        while (stack.size() > UNDO_DEPTH) stack.removeLast();
        REDO.remove(id); // a fresh edit invalidates the redo history
    }

    static String xyz(BlockPos p) { return p.getX() + ", " + p.getY() + ", " + p.getZ(); }
    public static void msg(ServerPlayer p, String t) { p.sendSystemMessage(Component.literal(access().messagePrefix() + t)); }
}
