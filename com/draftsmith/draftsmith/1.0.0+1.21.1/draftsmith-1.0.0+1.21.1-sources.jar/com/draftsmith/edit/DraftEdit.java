package com.draftsmith.edit;

import com.draftsmith.api.DraftSmithApi;
import com.draftsmith.api.EditAccess;
import com.draftsmith.compat.Compat;

import net.fabricmc.fabric.api.event.player.AttackBlockCallback;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.class_1269;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2247;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_9279;
import net.minecraft.class_9334;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.function.BiPredicate;

/**
 * "WorldEdit-lite", jailed by the host's {@link EditAccess}. Pick two corners (commands or the
 * editor wand), then set or replace — but every block written is checked against the access
 * provider first, so the edit physically cannot escape the area the player may build in. Each
 * edit snapshots the blocks it changes so undo can reverse it. Admins are unclamped but the
 * provider still has the final word per block.
 */
public final class DraftEdit {
    private static final String LEGACY_WAND_NAME = "plot_editor";     // pre-0.4.0 FabricPlots wands
    private static final String WAND_TAG = "draftsmith_wand";         // custom-data marker — survives anvil renames
    private static final String LEGACY_WAND_TAG = "fabricplots_wand"; // 0.4.0 FabricPlots wands
    private static final net.minecraft.class_1792 WAND_ITEM = class_1802.field_8406;
    private static final int MAX_BLOCKS = 65536;   // per edit — keeps a single op from freezing the server
    private static final int UNDO_DEPTH = 10;      // edits kept per player — brushes invite rapid strokes

    private static final class_2680 AIR = class_2246.field_10124.method_9564();

    static final Map<UUID, class_2338> POS1 = new HashMap<>(); // package-private: selection outline particles
    static final Map<UUID, class_2338> POS2 = new HashMap<>();
    private static final Map<UUID, Boolean> NEXT_IS_POS2 = new HashMap<>(); // wand alternation
    public record Snapshot(class_2338 pos, class_2680 old) {} // public: DraftShapes/DraftMeasure snapshot too
    private static final Map<UUID, Deque<List<Snapshot>>> UNDO = new HashMap<>();
    private static final Map<UUID, Deque<List<Snapshot>>> REDO = new HashMap<>();

    private record ClipBlock(int dx, int dy, int dz, class_2680 state) {} // clipboard, relative to copy origin
    public record Write(class_2338 pos, class_2680 state) {} // public: DraftBrush builds strokes
    private static final Map<UUID, List<ClipBlock>> CLIPBOARD = new HashMap<>();

    // Random-texture toggle: when ON, every written block rolls from the BLOCK items in the
    // player's hotbar (duplicate slots weight the mix). Session-only.
    private static final Set<UUID> RANDOM_TEXTURE = new HashSet<>();
    private static final java.util.Random RNG = new java.util.Random();

    private DraftEdit() {}

    static EditAccess access() { return DraftSmithApi.access(); }

    // ---- the editor wand (a tagged wooden axe) ----

    public static class_1799 createWand() {
        class_1799 s = new class_1799(WAND_ITEM);
        s.method_57379(class_9334.field_49631, class_2561.method_43470("Editor Wand"));
        // Data marker (same scheme as DraftBrush) so an anvil rename can't break the wand.
        class_2487 root = new class_2487();
        root.method_10566(WAND_TAG, new class_2487());
        s.method_57379(class_9334.field_49628, class_9279.method_57456(root));
        return s;
    }

    public static boolean isWand(class_1799 s) {
        if (s.method_7960() || s.method_7909() != WAND_ITEM) return false;
        class_9279 d = s.method_57824(class_9334.field_49628);
        if (d != null) {
            class_2487 t = d.method_57461();
            if (t.method_10545(WAND_TAG) || t.method_10545(LEGACY_WAND_TAG)) return true;
        }
        class_2561 n = s.method_57824(class_9334.field_49631); // legacy wands (pre-0.4.0) carry only the name
        return n != null && LEGACY_WAND_NAME.equals(n.getString());
    }

    public static void register() {
        // The wand never breaks blocks — left-click is swallowed.
        AttackBlockCallback.EVENT.register((player, world, hand, pos, dir) -> {
            if (!access().isActiveDimension(world)) return class_1269.field_5811;
            return isWand(player.method_5998(hand)) ? class_1269.field_5814 : class_1269.field_5811;
        });
        // Right-click sets a corner, alternating 1 → 2 → 1. SUCCESS so the client forwards the click.
        UseBlockCallback.EVENT.register((player, world, hand, hit) -> {
            if (!access().isActiveDimension(world)) return class_1269.field_5811;
            if (!isWand(player.method_5998(hand))) return class_1269.field_5811;
            if (player instanceof class_3222 sp) {
                if (!access().canUse(sp, EditAccess.Tool.WAND)) return class_1269.field_5811;
                boolean second = NEXT_IS_POS2.getOrDefault(sp.method_5667(), false);
                mark(sp, hit.method_17777(), !second);
                NEXT_IS_POS2.put(sp.method_5667(), !second);
            }
            return class_1269.field_5812;
        });
    }

    private static void mark(class_3222 sp, class_2338 pos, boolean isPos1) {
        (isPos1 ? POS1 : POS2).put(sp.method_5667(), pos.method_10062());
        msg(sp, "Corner " + (isPos1 ? "1" : "2") + " set at " + xyz(pos) + ".");
    }

    /** The block the player is holding (default state), or null if their main hand isn't a block. */
    public static class_2680 heldBlock(class_3222 sp) {
        return sp.method_6047().method_7909() instanceof net.minecraft.class_1747 bi
                ? bi.method_7711().method_9564() : null;
    }

    public static void setPos1(class_3222 sp) { POS1.put(sp.method_5667(), sp.method_24515().method_10062()); msg(sp, "Corner 1 set at " + xyz(sp.method_24515()) + "."); }
    public static void setPos2(class_3222 sp) { POS2.put(sp.method_5667(), sp.method_24515().method_10062()); msg(sp, "Corner 2 set at " + xyz(sp.method_24515()) + "."); }

    // ---- random texture --------------------------------------------------

    /** Toggle hotbar-random texturing for this player. Returns the new state. */
    public static boolean toggleRandomTexture(class_3222 sp) {
        UUID id = sp.method_5667();
        if (RANDOM_TEXTURE.remove(id)) return false;
        RANDOM_TEXTURE.add(id);
        return true;
    }

    public static boolean isRandomTexture(class_3222 sp) {
        return RANDOM_TEXTURE.contains(sp.method_5667());
    }

    // Re-entrancy guard for the hand-placement randomizer (main server thread only).
    private static boolean placingRandom = false;

    /**
     * Hand-placement half of the random-texture toggle (called from RandomTexturePlaceMixin):
     * with the toggle ON in an active dimension, placing a block by hand rolls the block from the
     * hotbar instead — lay a path without scrolling. Returns null to let vanilla placement run.
     * In survival the consumed item is moved to the block actually placed, so cheap blocks can't
     * be converted into rare ones.
     */
    public static class_1269 randomPlace(net.minecraft.class_1747 self,
                                                net.minecraft.class_1750 ctx) {
        if (placingRandom) return null;
        if (!(ctx.method_8045() instanceof class_3218 level)) return null; // server side decides
        if (!access().isActiveDimension(level)) return null;
        if (!(ctx.method_8036() instanceof class_3222 sp)) return null;
        if (!access().canUse(sp)) return null;
        if (!isRandomTexture(sp)) return null;
        List<net.minecraft.class_1747> pool = new ArrayList<>();
        for (int i = 0; i < 9; i++) {
            class_1799 s = sp.method_31548().method_5438(i);
            if (!s.method_7960() && s.method_7909() instanceof net.minecraft.class_1747 bi) pool.add(bi);
        }
        if (pool.isEmpty()) return null;
        net.minecraft.class_1747 rolled = pool.get(RNG.nextInt(pool.size()));
        if (rolled == self) return null; // rolled the held block — vanilla placement is already right

        class_1799 held = ctx.method_8041();
        int before = held.method_7947();
        class_1269 result;
        placingRandom = true;
        try { result = rolled.method_7712(ctx); } finally { placingRandom = false; }
        if (result.method_23665() && !sp.method_31549().field_7477 && held.method_7947() < before) {
            held.method_7933(1); // vanilla took it from the held stack — charge the rolled stack instead
            for (int i = 0; i < 9; i++) {
                class_1799 s = sp.method_31548().method_5438(i);
                if (s != held && !s.method_7960() && s.method_7909() == rolled) { s.method_7934(1); break; }
            }
        }
        return result;
    }

    /**
     * The material source for an edit: the held block — or, with random texture ON, a fresh roll
     * from the hotbar's block items per block written. Duplicate hotbar slots weight the mix.
     */
    static java.util.function.Supplier<class_2680> materials(class_3222 sp, class_2680 held) { // package-private: DraftShapes builds too
        if (!isRandomTexture(sp)) return () -> held;
        List<class_2680> pool = new ArrayList<>();
        for (int i = 0; i < 9; i++) {
            class_1799 s = sp.method_31548().method_5438(i);
            if (!s.method_7960() && s.method_7909() instanceof net.minecraft.class_1747 bi)
                pool.add(bi.method_7711().method_9564());
        }
        if (pool.isEmpty()) return () -> held;
        return () -> pool.get(RNG.nextInt(pool.size()));
    }

    // ---- operations ------------------------------------------------------

    public static int set(class_3222 sp, class_3218 level, class_2680 state) {
        return applyEdit(sp, level, (lvl, p) -> true, materials(sp, state), "Set");
    }

    public static int replace(class_3222 sp, class_3218 level, class_2247 from, class_2680 to) {
        return applyEdit(sp, level, from::method_35758, materials(sp, to), "Replaced");
    }

    private static int applyEdit(class_3222 sp, class_3218 level, BiPredicate<class_3218, class_2338> include,
                                 class_2680 newState, String verb) {
        return applyEdit(sp, level, include, () -> newState, verb);
    }

    private static int applyEdit(class_3222 sp, class_3218 level, BiPredicate<class_3218, class_2338> include,
                                 java.util.function.Supplier<class_2680> material, String verb) {
        UUID id = sp.method_5667();
        class_2338 p1 = POS1.get(id), p2 = POS2.get(id);
        if (p1 == null || p2 == null) { msg(sp, "Set both corners first — /draft pos1 and /draft pos2, or grab the wand with /draft wand."); return 0; }
        final boolean admin = access().isAdmin(sp);
        final int x1 = Math.min(p1.method_10263(), p2.method_10263()), x2 = Math.max(p1.method_10263(), p2.method_10263());
        final int z1 = Math.min(p1.method_10260(), p2.method_10260()), z2 = Math.max(p1.method_10260(), p2.method_10260());
        final int y1 = Math.max(access().minY(level), Math.min(p1.method_10264(), p2.method_10264()));
        final int y2 = Math.min(access().maxY(level), Math.max(p1.method_10264(), p2.method_10264()));

        List<Snapshot> snaps = new ArrayList<>();
        class_2338.class_2339 pos = new class_2338.class_2339();
        for (int x = x1; x <= x2; x++) {
            for (int z = z1; z <= z2; z++) {
                for (int y = y1; y <= y2; y++) {
                    if (!access().canEdit(sp, admin, x, y, z)) continue;    // the jail — asked per block
                    pos.method_10103(x, y, z);
                    if (!include.test(level, pos)) continue;                // replace: only matching blocks
                    snaps.add(new Snapshot(pos.method_10062(), level.method_8320(pos)));
                    if (snaps.size() > MAX_BLOCKS) { msg(sp, "That's over " + MAX_BLOCKS + " blocks — narrow your selection."); return 0; }
                }
            }
        }
        if (snaps.isEmpty()) { msg(sp, "Nothing to change — make sure the selection overlaps " + access().editableAreaName() + "."); return 0; }
        for (Snapshot s : snaps) level.method_8652(s.pos(), material.get(), class_2248.field_31028);
        pushUndo(id, snaps);
        msg(sp, verb + " " + snaps.size() + " block" + (snaps.size() == 1 ? "" : "s") + ". /draft undo to revert.");
        return 1;
    }

    public static int undo(class_3222 sp, class_3218 level) {
        return step(sp, level, UNDO, REDO, "Nothing to undo.", "Undone");
    }

    public static int redo(class_3222 sp, class_3218 level) {
        return step(sp, level, REDO, UNDO, "Nothing to redo.", "Redone");
    }

    /** Pop one edit off {@code from}, restore those blocks, and push the pre-restore state onto {@code to}. */
    private static int step(class_3222 sp, class_3218 level, Map<UUID, Deque<List<Snapshot>>> from,
                            Map<UUID, Deque<List<Snapshot>>> to, String empty, String verb) {
        Deque<List<Snapshot>> stack = from.get(sp.method_5667());
        if (stack == null || stack.isEmpty()) { msg(sp, empty); return 0; }
        List<Snapshot> edit = stack.pop();
        List<Snapshot> inverse = new ArrayList<>(edit.size());
        for (Snapshot s : edit) {
            inverse.add(new Snapshot(s.pos(), level.method_8320(s.pos())));
            level.method_8652(s.pos(), s.old(), class_2248.field_31028);
        }
        to.computeIfAbsent(sp.method_5667(), k -> new ArrayDeque<>()).push(inverse);
        msg(sp, verb + " — " + edit.size() + " block" + (edit.size() == 1 ? "" : "s") + ".");
        return 1;
    }

    // ---- clipboard: copy / cut / paste / stack / move --------------------

    public static int copy(class_3222 sp, class_3218 level) {
        int n = doCopy(sp, level);
        if (n < 0) return 0;
        msg(sp, "Copied " + n + " blocks. Aim (or stand) where you want it and /draft paste.");
        return 1;
    }

    public static int cut(class_3222 sp, class_3218 level) {
        if (doCopy(sp, level) < 0) return 0;
        return applyEdit(sp, level, (l, p) -> true, AIR, "Cut"); // copy, then clear the selection (clamped)
    }

    /** Capture the selection into the player's clipboard, relative to their position. -1 on error. */
    private static int doCopy(class_3222 sp, class_3218 level) {
        UUID id = sp.method_5667();
        class_2338 p1 = POS1.get(id), p2 = POS2.get(id);
        if (p1 == null || p2 == null) { msg(sp, "Set both corners first."); return -1; }
        class_2338 origin = sp.method_24515();
        int x1 = Math.min(p1.method_10263(), p2.method_10263()), x2 = Math.max(p1.method_10263(), p2.method_10263());
        int z1 = Math.min(p1.method_10260(), p2.method_10260()), z2 = Math.max(p1.method_10260(), p2.method_10260());
        int y1 = Math.max(access().minY(level), Math.min(p1.method_10264(), p2.method_10264()));
        int y2 = Math.min(access().maxY(level), Math.max(p1.method_10264(), p2.method_10264()));
        List<ClipBlock> clip = new ArrayList<>();
        class_2338.class_2339 pos = new class_2338.class_2339();
        for (int x = x1; x <= x2; x++) for (int z = z1; z <= z2; z++) for (int y = y1; y <= y2; y++) {
            pos.method_10103(x, y, z);
            clip.add(new ClipBlock(x - origin.method_10263(), y - origin.method_10264(), z - origin.method_10260(), level.method_8320(pos)));
            if (clip.size() > MAX_BLOCKS) { msg(sp, "Selection too big to copy (over " + MAX_BLOCKS + ")."); return -1; }
        }
        CLIPBOARD.put(id, clip);
        return clip.size();
    }

    public static int paste(class_3222 sp, class_3218 level) {
        List<ClipBlock> clip = CLIPBOARD.get(sp.method_5667());
        if (clip == null || clip.isEmpty()) { msg(sp, "Nothing to paste — /draft copy first."); return 0; }
        boolean admin = access().isAdmin(sp);
        // Land the paste where the player is AIMING (same raycast as the brushes) — one above the
        // hit block, so aiming at the ground behaves exactly like standing there. No block in range
        // falls back to the old behavior: paste at your feet.
        class_2338 origin = sp.method_24515();
        net.minecraft.class_239 hit = sp.method_5745(30, 0f, false);
        if (hit.method_17783() == net.minecraft.class_239.class_240.field_1332)
            origin = ((net.minecraft.class_3965) hit).method_17777().method_10084();
        List<Write> writes = new ArrayList<>();
        int skipped = 0;
        for (ClipBlock c : clip) {
            if (c.state().method_26215()) continue; // stamp solids only, don't erase the surroundings
            int x = origin.method_10263() + c.dx(), y = origin.method_10264() + c.dy(), z = origin.method_10260() + c.dz();
            if (!canEdit(sp, admin, x, y, z)) { skipped++; continue; }
            writes.add(new Write(new class_2338(x, y, z), c.state()));
        }
        int r = commit(sp, level, writes, "Pasted");
        if (r == 1 && skipped > 0) msg(sp, "(" + skipped + " blocks skipped — outside " + access().editableAreaName() + ".)");
        return r;
    }

    public static int stack(class_3222 sp, class_3218 level, int count) {
        UUID id = sp.method_5667();
        class_2338 p1 = POS1.get(id), p2 = POS2.get(id);
        if (p1 == null || p2 == null) { msg(sp, "Set both corners first."); return 0; }
        boolean admin = access().isAdmin(sp);
        class_2350 dir = sp.method_5735();
        int x1 = Math.min(p1.method_10263(), p2.method_10263()), x2 = Math.max(p1.method_10263(), p2.method_10263());
        int z1 = Math.min(p1.method_10260(), p2.method_10260()), z2 = Math.max(p1.method_10260(), p2.method_10260());
        int y1 = Math.max(access().minY(level), Math.min(p1.method_10264(), p2.method_10264()));
        int y2 = Math.min(access().maxY(level), Math.max(p1.method_10264(), p2.method_10264()));
        int span = switch (dir.method_10166()) { case field_11048 -> x2 - x1 + 1; case field_11051 -> z2 - z1 + 1; default -> y2 - y1 + 1; };
        List<Write> writes = new ArrayList<>();
        class_2338.class_2339 pos = new class_2338.class_2339();
        for (int i = 1; i <= count; i++) {
            int ox = dir.method_10148() * span * i, oy = dir.method_10164() * span * i, oz = dir.method_10165() * span * i;
            for (int x = x1; x <= x2; x++) for (int z = z1; z <= z2; z++) for (int y = y1; y <= y2; y++) {
                pos.method_10103(x, y, z);
                class_2680 src = level.method_8320(pos); // source region never overlaps a destination
                int nx = x + ox, ny = y + oy, nz = z + oz;
                if (!canEdit(sp, admin, nx, ny, nz)) continue;
                writes.add(new Write(new class_2338(nx, ny, nz), src));
            }
        }
        return commit(sp, level, writes, "Stacked x" + count + " →");
    }

    public static int move(class_3222 sp, class_3218 level, int count) {
        UUID id = sp.method_5667();
        class_2338 p1 = POS1.get(id), p2 = POS2.get(id);
        if (p1 == null || p2 == null) { msg(sp, "Set both corners first."); return 0; }
        boolean admin = access().isAdmin(sp);
        class_2350 dir = sp.method_5735();
        int ox = dir.method_10148() * count, oy = dir.method_10164() * count, oz = dir.method_10165() * count;
        int x1 = Math.min(p1.method_10263(), p2.method_10263()), x2 = Math.max(p1.method_10263(), p2.method_10263());
        int z1 = Math.min(p1.method_10260(), p2.method_10260()), z2 = Math.max(p1.method_10260(), p2.method_10260());
        int y1 = Math.max(access().minY(level), Math.min(p1.method_10264(), p2.method_10264()));
        int y2 = Math.min(access().maxY(level), Math.max(p1.method_10264(), p2.method_10264()));
        List<Write> clears = new ArrayList<>(), places = new ArrayList<>();
        class_2338.class_2339 pos = new class_2338.class_2339();
        for (int x = x1; x <= x2; x++) for (int z = z1; z <= z2; z++) for (int y = y1; y <= y2; y++) {
            if (!canEdit(sp, admin, x, y, z)) continue; // only move blocks you own
            pos.method_10103(x, y, z);
            class_2680 src = level.method_8320(pos);
            clears.add(new Write(new class_2338(x, y, z), AIR));
            int nx = x + ox, ny = y + oy, nz = z + oz;
            if (canEdit(sp, admin, nx, ny, nz)) places.add(new Write(new class_2338(nx, ny, nz), src));
        }
        List<Write> writes = new ArrayList<>(clears); // clear first, then place (place wins on overlap)
        writes.addAll(places);
        return commit(sp, level, writes, "Moved");
    }

    // ---- shapes ----------------------------------------------------------

    public static int walls(class_3222 sp, class_3218 level, class_2680 state) {
        UUID id = sp.method_5667();
        class_2338 p1 = POS1.get(id), p2 = POS2.get(id);
        if (p1 == null || p2 == null) { msg(sp, "Set both corners first."); return 0; }
        boolean admin = access().isAdmin(sp);
        int x1 = Math.min(p1.method_10263(), p2.method_10263()), x2 = Math.max(p1.method_10263(), p2.method_10263());
        int z1 = Math.min(p1.method_10260(), p2.method_10260()), z2 = Math.max(p1.method_10260(), p2.method_10260());
        int y1 = Math.max(access().minY(level), Math.min(p1.method_10264(), p2.method_10264()));
        int y2 = Math.min(access().maxY(level), Math.max(p1.method_10264(), p2.method_10264()));
        var mat = materials(sp, state);
        List<Write> writes = new ArrayList<>();
        for (int x = x1; x <= x2; x++) for (int z = z1; z <= z2; z++) {
            if (x != x1 && x != x2 && z != z1 && z != z2) continue; // perimeter only
            for (int y = y1; y <= y2; y++) if (canEdit(sp, admin, x, y, z)) writes.add(new Write(new class_2338(x, y, z), mat.get()));
        }
        return commit(sp, level, writes, "Built walls —");
    }

    public static int sphere(class_3222 sp, class_3218 level, class_2680 state, int r, boolean hollow) {
        boolean admin = access().isAdmin(sp);
        class_2338 c = sp.method_24515();
        double outer = r + 0.5, inner = r - 0.5;
        var mat = materials(sp, state);
        List<Write> writes = new ArrayList<>();
        for (int dx = -r; dx <= r; dx++) for (int dy = -r; dy <= r; dy++) for (int dz = -r; dz <= r; dz++) {
            double dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
            if (dist > outer || (hollow && dist < inner)) continue;
            int x = c.method_10263() + dx, y = c.method_10264() + dy, z = c.method_10260() + dz;
            if (canEdit(sp, admin, x, y, z)) writes.add(new Write(new class_2338(x, y, z), mat.get()));
        }
        return commit(sp, level, writes, hollow ? "Hollow sphere —" : "Sphere —");
    }

    public static int cylinder(class_3222 sp, class_3218 level, class_2680 state, int r, int height) {
        boolean admin = access().isAdmin(sp);
        class_2338 c = sp.method_24515();
        double rr = (r + 0.5) * (r + 0.5);
        var mat = materials(sp, state);
        List<Write> writes = new ArrayList<>();
        for (int dx = -r; dx <= r; dx++) for (int dz = -r; dz <= r; dz++) {
            if (dx * dx + dz * dz > rr) continue;
            for (int dy = 0; dy < height; dy++) {
                int x = c.method_10263() + dx, y = c.method_10264() + dy, z = c.method_10260() + dz;
                if (canEdit(sp, admin, x, y, z)) writes.add(new Write(new class_2338(x, y, z), mat.get()));
            }
        }
        return commit(sp, level, writes, "Cylinder —");
    }

    // ---- shared lookups --------------------------------------------------

    /** Registry-ID lookup via the version seam — colored blocks stay identical across branches. */
    static class_2248 blockById(String id) { // package-private: DraftMeasure's tape blocks
        return Compat.block(id);
    }

    /** Snapshot (deduped, original states), apply all writes, push one undo entry. */
    public static int commit(class_3222 sp, class_3218 level, List<Write> writes, String verb) {
        if (writes.isEmpty()) { msg(sp, "Nothing to change — make sure it lands on " + access().editableAreaName() + "."); return 0; }
        if (writes.size() > MAX_BLOCKS) { msg(sp, "That's over " + MAX_BLOCKS + " blocks — use a smaller selection or count."); return 0; }
        Set<class_2338> seen = new HashSet<>();
        List<Snapshot> snaps = new ArrayList<>();
        for (Write w : writes) if (seen.add(w.pos())) snaps.add(new Snapshot(w.pos(), level.method_8320(w.pos())));
        for (Write w : writes) level.method_8652(w.pos(), w.state(), class_2248.field_31028);
        pushUndo(sp.method_5667(), snaps);
        msg(sp, verb + " " + writes.size() + " blocks. /draft undo to revert.");
        return 1;
    }

    /** Can this player write at x/y/z? Delegates to the host's access provider — the jail. */
    public static boolean canEdit(class_3222 sp, boolean admin, int x, int y, int z) {
        return access().canEdit(sp, admin, x, y, z);
    }

    private static void pushUndo(UUID id, List<Snapshot> snaps) {
        Deque<List<Snapshot>> stack = UNDO.computeIfAbsent(id, k -> new ArrayDeque<>());
        stack.push(snaps);
        while (stack.size() > UNDO_DEPTH) stack.removeLast();
        REDO.remove(id); // a fresh edit invalidates the redo history
    }

    static String xyz(class_2338 p) { return p.method_10263() + ", " + p.method_10264() + ", " + p.method_10260(); }
    public static void msg(class_3222 p, String t) { p.method_43496(class_2561.method_43470(access().messagePrefix() + t)); }
}
