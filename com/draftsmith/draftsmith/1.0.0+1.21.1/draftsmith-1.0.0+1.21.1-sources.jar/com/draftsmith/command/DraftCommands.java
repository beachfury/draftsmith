package com.draftsmith.command;

import com.draftsmith.api.DraftSmithApi;
import com.draftsmith.api.EditAccess;
import com.draftsmith.config.DraftConfig;
import com.draftsmith.edit.DraftBrush;
import com.draftsmith.edit.DraftEdit;
import com.draftsmith.edit.DraftMeasure;
import com.draftsmith.edit.DraftShapes;
import com.draftsmith.gui.DraftEditGui;
import com.draftsmith.gui.DraftMeasureGui;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2257;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_7157;

/**
 * The editor commands: wand, brush, selection, set/replace, clipboard, shapes and the measuring
 * tape. Standalone they live under the /draft root ({@link #register}); a host mod can instead
 * chain the exact same nodes onto its own root with {@link #attach} — the handlers are shared,
 * only the root differs.
 */
public final class DraftCommands {
    private DraftCommands() {}

    private static EditAccess access() { return DraftSmithApi.access(); }

    /** Standalone registration: the /draft root. Hidden entirely from players who can't use it. */
    public static void register(CommandDispatcher<class_2168> d, class_7157 bc) {
        LiteralArgumentBuilder<class_2168> root = class_2170.method_9247("draft")
                .requires(src -> src.method_44023() != null && access().canUse(src.method_44023()))
                .executes(DraftCommands::editGui) // bare /draft opens the editor hub
                // The selection wand is DraftSmith's own tool — /draft wand only, never attached
                // to a host root ("editwand" kept as a quiet alias for FabricPlots muscle memory).
                .then(class_2170.method_9247("wand").executes(DraftCommands::editwand))
                .then(class_2170.method_9247("editwand").executes(DraftCommands::editwand))
                .then(class_2170.method_9247("help").executes(DraftCommands::help))
                .then(class_2170.method_9247("reload")
                        .requires(src -> src.method_44023() == null || access().isAdmin(src.method_44023()))
                        .executes(ctx -> {
                            DraftConfig.load();
                            // Re-send command trees — a newly-listed editor sees /draft immediately.
                            var server = ctx.getSource().method_9211();
                            server.method_3760().method_14571().forEach(pl -> server.method_3734().method_9241(pl));
                            msg(ctx, "Config reloaded.");
                            return 1;
                        }));
        attach(root, bc);
        d.register(root);
    }

    /** Chain every editor subcommand onto any root builder (call before dispatcher.register). */
    public static void attach(LiteralArgumentBuilder<class_2168> root, class_7157 bc) {
        attach(root, bc, java.util.Set.of());
    }

    /**
     * Chain the editor subcommands onto any root builder, skipping the named ones — for hosts
     * that keep some tools under DraftSmith's own root instead of duplicating them (e.g.
     * {@code attach(root, bc, Set.of("brush"))}). Skipping "tape" removes "tape clear" with it.
     * The wand-getting command is NOT part of this set — it is /draft wand, DraftSmith's own.
     */
    public static void attach(LiteralArgumentBuilder<class_2168> root, class_7157 bc,
                              java.util.Set<String> skip) {
        java.util.function.Consumer<LiteralArgumentBuilder<class_2168>> add =
                node -> { if (!skip.contains(node.getLiteral())) root.then(node); };
        add.accept(class_2170.method_9247("brush").executes(DraftCommands::brush));
        add.accept(class_2170.method_9247("pos1").executes(DraftCommands::pos1));
        add.accept(class_2170.method_9247("pos2").executes(DraftCommands::pos2));
        add.accept(class_2170.method_9247("set")
                .then(class_2170.method_9244("block", class_2257.method_9653(bc))
                        .executes(DraftCommands::setBlocks)));
        add.accept(class_2170.method_9247("replace")
                .then(class_2170.method_9244("from", class_2257.method_9653(bc))
                        .then(class_2170.method_9244("to", class_2257.method_9653(bc))
                                .executes(DraftCommands::replaceBlocks))));
        add.accept(class_2170.method_9247("edit").executes(DraftCommands::editGui));
        add.accept(class_2170.method_9247("measure").executes(DraftCommands::measureGui));
        add.accept(class_2170.method_9247("undo").executes(DraftCommands::undoEdit));
        add.accept(class_2170.method_9247("redo").executes(DraftCommands::redoEdit));
        add.accept(class_2170.method_9247("copy").executes(DraftCommands::copyEdit));
        add.accept(class_2170.method_9247("cut").executes(DraftCommands::cutEdit));
        add.accept(class_2170.method_9247("paste").executes(DraftCommands::pasteEdit));
        add.accept(class_2170.method_9247("stack")
                .then(class_2170.method_9244("count", IntegerArgumentType.integer(1, 64))
                        .executes(ctx -> stackEdit(ctx, IntegerArgumentType.getInteger(ctx, "count")))));
        add.accept(class_2170.method_9247("move")
                .then(class_2170.method_9244("count", IntegerArgumentType.integer(1, 256))
                        .executes(ctx -> moveEdit(ctx, IntegerArgumentType.getInteger(ctx, "count")))));
        add.accept(class_2170.method_9247("walls")
                .then(class_2170.method_9244("block", class_2257.method_9653(bc))
                        .executes(DraftCommands::wallsEdit)));
        add.accept(class_2170.method_9247("sphere")
                .then(class_2170.method_9244("block", class_2257.method_9653(bc))
                        .then(class_2170.method_9244("radius", IntegerArgumentType.integer(1, 32))
                                .executes(ctx -> sphereEdit(ctx, false)))));
        add.accept(class_2170.method_9247("hsphere")
                .then(class_2170.method_9244("block", class_2257.method_9653(bc))
                        .then(class_2170.method_9244("radius", IntegerArgumentType.integer(1, 32))
                                .executes(ctx -> sphereEdit(ctx, true)))));
        add.accept(class_2170.method_9247("cyl")
                .then(class_2170.method_9244("block", class_2257.method_9653(bc))
                        .then(class_2170.method_9244("radius", IntegerArgumentType.integer(1, 32))
                                .executes(ctx -> cylEdit(ctx, 1))
                                .then(class_2170.method_9244("height", IntegerArgumentType.integer(1, 256))
                                        .executes(ctx -> cylEdit(ctx, IntegerArgumentType.getInteger(ctx, "height")))))));
        add.accept(class_2170.method_9247("disc")
                .then(class_2170.method_9244("block", class_2257.method_9653(bc))
                        .then(class_2170.method_9244("size", IntegerArgumentType.integer(1, 256))
                                .executes(ctx -> shapeEdit(ctx, DraftShapes.Shape.CIRCLE, false, 1))
                                .then(class_2170.method_9244("height", IntegerArgumentType.integer(1, 128))
                                        .executes(ctx -> shapeEdit(ctx, DraftShapes.Shape.CIRCLE, false,
                                                IntegerArgumentType.getInteger(ctx, "height")))))));
        add.accept(class_2170.method_9247("ring")
                .then(class_2170.method_9244("block", class_2257.method_9653(bc))
                        .then(class_2170.method_9244("size", IntegerArgumentType.integer(1, 256))
                                .executes(ctx -> shapeEdit(ctx, DraftShapes.Shape.CIRCLE, true, 1))
                                .then(class_2170.method_9244("height", IntegerArgumentType.integer(1, 128))
                                        .executes(ctx -> shapeEdit(ctx, DraftShapes.Shape.CIRCLE, true,
                                                IntegerArgumentType.getInteger(ctx, "height")))))));
        add.accept(class_2170.method_9247("line")
                .then(class_2170.method_9244("block", class_2257.method_9653(bc))
                        .executes(ctx -> lineEdit(ctx, 1))
                        .then(class_2170.method_9244("thickness", IntegerArgumentType.integer(1, 8))
                                .executes(ctx -> lineEdit(ctx, IntegerArgumentType.getInteger(ctx, "thickness"))))));
        add.accept(class_2170.method_9247("center").executes(DraftCommands::centerEdit));
        add.accept(class_2170.method_9247("tape")
                .executes(DraftCommands::tapeEdit)
                .then(class_2170.method_9247("clear").executes(DraftCommands::tapeClear)));
    }

    // ---- guards ----------------------------------------------------------

    /**
     * The player, after the editor gate: allowed to use the editor AND standing in an active
     * dimension. Null (with the reason already messaged) when either fails.
     */
    private static class_3222 editor(CommandContext<class_2168> ctx) throws Exception {
        class_3222 p = ctx.getSource().method_9207();
        if (!access().canUse(p)) { msg(ctx, "You don't have permission to use the editor."); return null; }
        if (!access().isActiveDimension(p.method_37908())) { msg(ctx, access().notHereMessage()); return null; }
        return p;
    }

    /** The editor gate plus a tool-group check (draftsmith.wand/edit/shapes/brush/measure). */
    private static class_3222 editor(CommandContext<class_2168> ctx, EditAccess.Tool tool) throws Exception {
        class_3222 p = editor(ctx);
        if (p == null) return null;
        if (!access().canUse(p, tool)) { msg(ctx, noTool(tool)); return null; }
        return p;
    }

    /** Same gate minus the dimension check — for handing out tools (usable from anywhere). */
    private static class_3222 user(CommandContext<class_2168> ctx) throws Exception {
        class_3222 p = ctx.getSource().method_9207();
        if (!access().canUse(p)) { msg(ctx, "You don't have permission to use the editor."); return null; }
        return p;
    }

    private static class_3222 user(CommandContext<class_2168> ctx, EditAccess.Tool tool) throws Exception {
        class_3222 p = user(ctx);
        if (p == null) return null;
        if (!access().canUse(p, tool)) { msg(ctx, noTool(tool)); return null; }
        return p;
    }

    private static String noTool(EditAccess.Tool tool) {
        return "You don't have permission for the " + tool.name().toLowerCase(java.util.Locale.ROOT) + " tools.";
    }

    // ---- handlers --------------------------------------------------------

    private static int brush(CommandContext<class_2168> ctx) {
        try {
            class_3222 p = user(ctx, EditAccess.Tool.BRUSH);
            if (p == null) return 0;
            p.method_31548().method_7398(DraftBrush.createBrush());
            msg(ctx, "Paint brush added. Sneak + right-click to configure it, right-click to paint.");
            return 1;
        } catch (Exception e) { return err(ctx, e); }
    }

    private static int editwand(CommandContext<class_2168> ctx) {
        try {
            class_3222 p = user(ctx, EditAccess.Tool.WAND);
            if (p == null) return 0;
            p.method_7270(DraftEdit.createWand());
            msg(ctx, "Wand given. Right-click a block for corner 1, right-click again for corner 2 (or use /draft pos1 · /draft pos2). Then /draft set <block> or /draft replace <from> <to>.");
            return 1;
        } catch (Exception e) { return err(ctx, e); }
    }

    private static int pos1(CommandContext<class_2168> ctx) {
        try {
            class_3222 p = user(ctx);
            if (p == null) return 0;
            DraftEdit.setPos1(p);
            return 1;
        } catch (Exception e) { return err(ctx, e); }
    }

    private static int pos2(CommandContext<class_2168> ctx) {
        try {
            class_3222 p = user(ctx);
            if (p == null) return 0;
            DraftEdit.setPos2(p);
            return 1;
        } catch (Exception e) { return err(ctx, e); }
    }

    private static int setBlocks(CommandContext<class_2168> ctx) {
        try {
            class_3222 p = editor(ctx, EditAccess.Tool.EDIT);
            if (p == null) return 0;
            var block = class_2257.method_9655(ctx, "block");
            return DraftEdit.set(p, (class_3218) p.method_37908(), block.method_9494());
        } catch (Exception e) { return err(ctx, e); }
    }

    private static int replaceBlocks(CommandContext<class_2168> ctx) {
        try {
            class_3222 p = editor(ctx, EditAccess.Tool.EDIT);
            if (p == null) return 0;
            var from = class_2257.method_9655(ctx, "from");
            var to = class_2257.method_9655(ctx, "to");
            return DraftEdit.replace(p, (class_3218) p.method_37908(), from, to.method_9494());
        } catch (Exception e) { return err(ctx, e); }
    }

    private static int undoEdit(CommandContext<class_2168> ctx) {
        try {
            class_3222 p = editor(ctx);
            if (p == null) return 0;
            return DraftEdit.undo(p, (class_3218) p.method_37908());
        } catch (Exception e) { return err(ctx, e); }
    }

    private static int redoEdit(CommandContext<class_2168> ctx) {
        try {
            class_3222 p = editor(ctx);
            if (p == null) return 0;
            return DraftEdit.redo(p, (class_3218) p.method_37908());
        } catch (Exception e) { return err(ctx, e); }
    }

    private static int editGui(CommandContext<class_2168> ctx) {
        try {
            class_3222 p = editor(ctx);
            if (p == null) return 0;
            DraftEditGui.open(p);
            return 1;
        } catch (Exception e) { return err(ctx, e); }
    }

    private static int measureGui(CommandContext<class_2168> ctx) {
        try {
            class_3222 p = editor(ctx, EditAccess.Tool.MEASURE);
            if (p == null) return 0;
            DraftMeasureGui.open(p);
            return 1;
        } catch (Exception e) { return err(ctx, e); }
    }

    private static int wallsEdit(CommandContext<class_2168> ctx) {
        try {
            class_3222 p = editor(ctx, EditAccess.Tool.EDIT);
            if (p == null) return 0;
            return DraftEdit.walls(p, (class_3218) p.method_37908(), class_2257.method_9655(ctx, "block").method_9494());
        } catch (Exception e) { return err(ctx, e); }
    }

    private static int sphereEdit(CommandContext<class_2168> ctx, boolean hollow) {
        try {
            class_3222 p = editor(ctx, EditAccess.Tool.SHAPES);
            if (p == null) return 0;
            int r = IntegerArgumentType.getInteger(ctx, "radius");
            return DraftEdit.sphere(p, (class_3218) p.method_37908(), class_2257.method_9655(ctx, "block").method_9494(), r, hollow);
        } catch (Exception e) { return err(ctx, e); }
    }

    private static int cylEdit(CommandContext<class_2168> ctx, int height) {
        try {
            class_3222 p = editor(ctx, EditAccess.Tool.SHAPES);
            if (p == null) return 0;
            int r = IntegerArgumentType.getInteger(ctx, "radius");
            return DraftEdit.cylinder(p, (class_3218) p.method_37908(), class_2257.method_9655(ctx, "block").method_9494(), r, height);
        } catch (Exception e) { return err(ctx, e); }
    }

    private static int shapeEdit(CommandContext<class_2168> ctx, DraftShapes.Shape shape, boolean hollow, int height) {
        try {
            class_3222 p = editor(ctx, EditAccess.Tool.SHAPES);
            if (p == null) return 0;
            int size = IntegerArgumentType.getInteger(ctx, "size");
            return DraftShapes.buildShape(p, (class_3218) p.method_37908(), class_2257.method_9655(ctx, "block").method_9494(),
                    shape, hollow, size, height, 1, 1, 0);
        } catch (Exception e) { return err(ctx, e); }
    }

    private static int lineEdit(CommandContext<class_2168> ctx, int thickness) {
        try {
            class_3222 p = editor(ctx, EditAccess.Tool.SHAPES);
            if (p == null) return 0;
            return DraftShapes.line(p, (class_3218) p.method_37908(), class_2257.method_9655(ctx, "block").method_9494(), thickness);
        } catch (Exception e) { return err(ctx, e); }
    }

    private static int centerEdit(CommandContext<class_2168> ctx) {
        try {
            class_3222 p = editor(ctx, EditAccess.Tool.MEASURE);
            if (p == null) return 0;
            return DraftShapes.findLineCenter(p, (class_3218) p.method_37908());
        } catch (Exception e) { return err(ctx, e); }
    }

    private static int tapeEdit(CommandContext<class_2168> ctx) {
        try {
            class_3222 p = editor(ctx, EditAccess.Tool.MEASURE);
            if (p == null) return 0;
            return DraftMeasure.tape(p, (class_3218) p.method_37908());
        } catch (Exception e) { return err(ctx, e); }
    }

    private static int tapeClear(CommandContext<class_2168> ctx) {
        try {
            class_3222 p = editor(ctx, EditAccess.Tool.MEASURE);
            if (p == null) return 0;
            DraftMeasure.clearTape(p, (class_3218) p.method_37908());
            msg(ctx, "Measuring tape cleared.");
            return 1;
        } catch (Exception e) { return err(ctx, e); }
    }

    private static int copyEdit(CommandContext<class_2168> ctx) {
        try {
            class_3222 p = editor(ctx, EditAccess.Tool.EDIT);
            if (p == null) return 0;
            return DraftEdit.copy(p, (class_3218) p.method_37908());
        } catch (Exception e) { return err(ctx, e); }
    }

    private static int cutEdit(CommandContext<class_2168> ctx) {
        try {
            class_3222 p = editor(ctx, EditAccess.Tool.EDIT);
            if (p == null) return 0;
            return DraftEdit.cut(p, (class_3218) p.method_37908());
        } catch (Exception e) { return err(ctx, e); }
    }

    private static int pasteEdit(CommandContext<class_2168> ctx) {
        try {
            class_3222 p = editor(ctx, EditAccess.Tool.EDIT);
            if (p == null) return 0;
            return DraftEdit.paste(p, (class_3218) p.method_37908());
        } catch (Exception e) { return err(ctx, e); }
    }

    private static int stackEdit(CommandContext<class_2168> ctx, int count) {
        try {
            class_3222 p = editor(ctx, EditAccess.Tool.EDIT);
            if (p == null) return 0;
            return DraftEdit.stack(p, (class_3218) p.method_37908(), count);
        } catch (Exception e) { return err(ctx, e); }
    }

    private static int moveEdit(CommandContext<class_2168> ctx, int count) {
        try {
            class_3222 p = editor(ctx, EditAccess.Tool.EDIT);
            if (p == null) return 0;
            return DraftEdit.move(p, (class_3218) p.method_37908(), count);
        } catch (Exception e) { return err(ctx, e); }
    }

    // ---- help ------------------------------------------------------------

    private static final int CLR_TEAL = 0x1ABC9C, CLR_YELLOW = 0xFFE066, CLR_PURPLE = 0xC792EA;

    private static int help(CommandContext<class_2168> ctx) {
        class_2168 src = ctx.getSource();
        src.method_9226(() -> class_2561.method_43470("DraftSmith").method_27694(s -> s.method_36139(CLR_TEAL))
                .method_10852(class_2561.method_43470(" — build tools (click a command to fill it in)").method_27694(s -> s.method_36139(CLR_PURPLE))), false);

        section(src, "Tools");
        line(src, "/draft", "open the editor hub — every tool below as a GUI");
        line(src, "/draft wand", "get the selection wand (right-click corners 1 / 2)");
        line(src, "/draft brush", "get a paint brush (sneak + right-click configures it)");

        section(src, "Selection & clipboard");
        line(src, "/draft pos1", "set corner 1 where you stand");
        line(src, "/draft pos2", "set corner 2 where you stand");
        line(src, "/draft copy", "copy the selection");
        line(src, "/draft cut", "copy, then clear the selection");
        line(src, "/draft paste", "paste where you aim");
        line(src, "/draft stack <count>", "repeat the selection along your facing");
        line(src, "/draft move <count>", "shift the selection along your facing");

        section(src, "Editing");
        line(src, "/draft set <block>", "fill the selection");
        line(src, "/draft replace <from> <to>", "replace only matching blocks");
        line(src, "/draft walls <block>", "perimeter walls around the selection");
        line(src, "/draft undo", "step the last edit back (10 deep)");
        line(src, "/draft redo", "step forward again");

        section(src, "Shapes");
        line(src, "/draft sphere <block> <radius>", "sphere where you stand");
        line(src, "/draft hsphere <block> <radius>", "hollow sphere");
        line(src, "/draft cyl <block> <radius> [height]", "cylinder");
        line(src, "/draft disc <block> <size> [height]", "flat disc");
        line(src, "/draft ring <block> <size> [height]", "ring");
        line(src, "/draft line <block> [thickness]", "3D line, corner 1 → corner 2");

        section(src, "Measuring");
        line(src, "/draft measure", "open the measuring screen");
        line(src, "/draft center", "gold-mark the middle of the corner 1 → corner 2 line");
        line(src, "/draft tape", "lay a numbered measuring tape between the corners");
        line(src, "/draft tape clear", "remove your tapes (restores what they covered)");

        class_3222 p = src.method_44023();
        if (p == null || access().isAdmin(p)) {
            section(src, "Admin");
            line(src, "/draft reload", "reload config/draftsmith.properties");
        }
        return 1;
    }

    private static void section(class_2168 src, String title) {
        src.method_9226(() -> class_2561.method_43470(title).method_27694(s -> s.method_36139(CLR_PURPLE).method_27706(net.minecraft.class_124.field_1067)), false);
    }

    private static void line(class_2168 src, String command, String desc) {
        int cut = command.length();
        int lt = command.indexOf('<'), br = command.indexOf('[');
        if (lt >= 0) cut = lt;
        if (br >= 0 && br < cut) cut = br;
        final String suggest = command.substring(0, cut); // drop <args>/[args] from what gets typed
        src.method_9226(() -> class_2561.method_43470("  " + command)
                .method_27694(s -> s.method_36139(CLR_YELLOW).method_10958(com.draftsmith.compat.Compat.suggestCommand(suggest)))
                .method_10852(class_2561.method_43470("   " + desc).method_27694(s -> s.method_36139(CLR_PURPLE))), false);
    }

    // ---- helpers ---------------------------------------------------------

    private static void msg(CommandContext<class_2168> ctx, String text) {
        ctx.getSource().method_9226(() -> class_2561.method_43470(access().messagePrefix() + text), false);
    }

    private static int err(CommandContext<class_2168> ctx, Exception e) {
        ctx.getSource().method_9213(class_2561.method_43470(access().messagePrefix() + "Error: " + e.getMessage()));
        return 0;
    }
}
